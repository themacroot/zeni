import axios from 'axios';

// RBI API Service for Regulatory Compliance
class RBIApiService {
  constructor() {
    this.baseURL = import.meta.env?.VITE_RBI_API_URL || 'https://your-rbi-api-endpoint.com';
    this.apiKey = import.meta.env?.VITE_RBI_API_KEY;
    
    this.axiosInstance = axios?.create({
      baseURL: this.baseURL,
      headers: {
        'Content-Type': 'application/json',
        ...(this.apiKey && { 'Authorization': `Bearer ${this.apiKey}` }),
      },
      timeout: 30000, // 30 second timeout for regulatory compliance queries
    });

    // Add request interceptor for logging
    this.axiosInstance?.interceptors?.request?.use(
      (config) => {
        console.log('RBI API Request:', {
          url: config?.url,
          method: config?.method,
          data: config?.data
        });
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Add response interceptor for error handling
    this.axiosInstance?.interceptors?.response?.use(
      (response) => {
        console.log('RBI API Response:', response?.data);
        return response;
      },
      (error) => {
        console.error('RBI API Error:', error);
        return Promise.reject(this.handleError(error));
      }
    );
  }

  handleError(error) {
    if (error?.response) {
      // Server responded with error status
      return {
        message: error?.response?.data?.message || 'RBI API request failed',
        status: error?.response?.status,
        data: error?.response?.data
      };
    } else if (error?.request) {
      // Request made but no response received
      return {
        message: 'No response from RBI API server',
        status: 0,
        data: null
      };
    } else {
      // Something else happened
      return {
        message: error?.message || 'Unknown RBI API error',
        status: -1,
        data: null
      };
    }
  }

  /**
   * Send query to RBI API for regulatory compliance
   * @param {Array} context - Array of conversation messages
   * @param {string} chatType - Type of chat (should be 'rbi')
   * @returns {Promise} API response with answer and references
   */
  async queryRegulatory(context, chatType = 'rbi') {
    try {
      const payload = {
        context: context?.map(msg => ({
          role: msg?.role,
          content: msg?.content
        })),
        chat_type: chatType
      };

      const response = await this.axiosInstance?.post('/chat', payload);
      
      return {
        success: true,
        data: response?.data,
        timestamp: new Date()?.toISOString()
      };
    } catch (error) {
      return {
        success: false,
        error: error,
        timestamp: new Date()?.toISOString()
      };
    }
  }

  /**
   * Validate API configuration
   * @returns {boolean} Whether API is properly configured
   */
  isConfigured() {
    return Boolean(this.baseURL && this.baseURL !== 'https://your-rbi-api-endpoint.com');
  }

  /**
   * Test API connection
   * @returns {Promise} Connection test result
   */
  async testConnection() {
    try {
      const testPayload = {
        context: [
          {
            role: "user",
            content: "Test connection to RBI API"
          }
        ],
        chat_type: "rbi"
      };

      const response = await this.axiosInstance?.post('/chat', testPayload);
      return {
        success: true,
        message: 'RBI API connection successful',
        data: response?.data
      };
    } catch (error) {
      return {
        success: false,
        message: 'RBI API connection failed',
        error: error
      };
    }
  }
}

// Create singleton instance
const rbiApiService = new RBIApiService();

export default rbiApiService;