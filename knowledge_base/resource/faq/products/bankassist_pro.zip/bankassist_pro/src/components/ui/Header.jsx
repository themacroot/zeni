import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  const primaryNavItems = [
    {
      label: 'Chat Dashboard',
      path: '/chat-interface-dashboard',
      icon: 'MessageSquare',
      description: 'Active conversation workspace'
    },
    {
      label: 'Session Management',
      path: '/chat-session-management',
      icon: 'FolderOpen',
      description: 'Manage chat sessions and history'
    }
  ];

  const secondaryNavItems = [
    {
      label: 'Settings',
      path: '/settings',
      icon: 'Settings',
      description: 'Application preferences'
    },
    {
      label: 'Help & Support',
      path: '/help',
      icon: 'HelpCircle',
      description: 'Documentation and support'
    },
    {
      label: 'Admin Panel',
      path: '/admin',
      icon: 'Shield',
      description: 'Administrative controls'
    }
  ];

  const handleNavigation = (path) => {
    navigate(path);
    setIsMoreMenuOpen(false);
  };

  const isActivePath = (path) => {
    return location.pathname === path;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-100 bg-surface border-b border-subtle">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Logo Section */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
            <Icon 
              name="Building2" 
              size={24} 
              color="var(--color-primary-foreground)" 
              strokeWidth={2}
            />
          </div>
          <div className="flex flex-col">
            <h1 className="text-lg font-semibold text-text-primary leading-tight">
              BankAssist Pro
            </h1>
            <span className="text-xs text-text-secondary font-medium">
              Banking Intelligence Platform
            </span>
          </div>
        </div>

        {/* Primary Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {primaryNavItems.map((item) => (
            <Button
              key={item.path}
              variant={isActivePath(item.path) ? "default" : "ghost"}
              size="sm"
              onClick={() => handleNavigation(item.path)}
              iconName={item.icon}
              iconPosition="left"
              iconSize={16}
              className="px-4 py-2 text-sm font-medium transition-banking"
            >
              {item.label}
            </Button>
          ))}

          {/* More Menu */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
              iconName="MoreHorizontal"
              iconSize={16}
              className="px-3 py-2"
            >
              More
            </Button>

            {isMoreMenuOpen && (
              <>
                {/* Backdrop */}
                <div 
                  className="fixed inset-0 z-50" 
                  onClick={() => setIsMoreMenuOpen(false)}
                />
                
                {/* Dropdown Menu */}
                <div className="absolute right-0 top-full mt-2 w-56 bg-popover border border-subtle rounded-lg elevation-2 z-60 animate-fade-in">
                  <div className="py-2">
                    {secondaryNavItems.map((item) => (
                      <button
                        key={item.path}
                        onClick={() => handleNavigation(item.path)}
                        className="w-full flex items-center px-4 py-3 text-sm text-text-primary hover:bg-muted transition-banking focus-banking"
                      >
                        <Icon 
                          name={item.icon} 
                          size={16} 
                          className="mr-3 text-text-secondary" 
                        />
                        <div className="flex flex-col items-start">
                          <span className="font-medium">{item.label}</span>
                          <span className="text-xs text-text-secondary">
                            {item.description}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </nav>

        {/* User Profile & Actions */}
        <div className="flex items-center space-x-3">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative"
          >
            <Icon name="Bell" size={20} />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-error rounded-full"></span>
          </Button>

          {/* User Profile */}
          <div className="flex items-center space-x-3 pl-3 border-l border-subtle">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-sm font-medium text-text-primary">
                Sarah Johnson
              </span>
              <span className="text-xs text-text-secondary">
                Compliance Officer
              </span>
            </div>
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-sm font-semibold text-primary-foreground">
                SJ
              </span>
            </div>
          </div>
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
        >
          <Icon name="Menu" size={20} />
        </Button>
      </div>

      {/* Mobile Navigation Menu */}
      {isMoreMenuOpen && (
        <div className="md:hidden bg-surface border-t border-subtle">
          <div className="py-2">
            {[...primaryNavItems, ...secondaryNavItems].map((item) => (
              <button
                key={item.path}
                onClick={() => handleNavigation(item.path)}
                className={`w-full flex items-center px-6 py-3 text-sm transition-banking focus-banking ${
                  isActivePath(item.path)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-text-primary hover:bg-muted'
                }`}
              >
                <Icon 
                  name={item.icon} 
                  size={16} 
                  className="mr-3" 
                />
                <div className="flex flex-col items-start">
                  <span className="font-medium">{item.label}</span>
                  <span className="text-xs opacity-75">
                    {item.description}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;