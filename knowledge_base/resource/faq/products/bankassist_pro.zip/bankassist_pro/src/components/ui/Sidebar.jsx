import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [currentMode, setCurrentMode] = useState('regulatory');
  const [selectedSession, setSelectedSession] = useState(null);
  const [sessionManagementVisible, setSessionManagementVisible] = useState(false);

  // Mock chat sessions data
  const [chatSessions] = useState([
    {
      id: 1,
      title: 'Regulatory Compliance Q3 2025',
      mode: 'regulatory',
      timestamp: '2025-07-28T09:30:00',
      messageCount: 24,
      participants: ['Sarah Johnson'],
      complianceFlags: ['high-priority']
    },
    {
      id: 2,
      title: 'Policy Analysis - New Banking Rules',
      mode: 'policy',
      timestamp: '2025-07-28T08:45:00',
      messageCount: 18,
      participants: ['Sarah Johnson', 'Mike Chen'],
      complianceFlags: []
    },
    {
      id: 3,
      title: 'Competitive Intelligence Review',
      mode: 'competitive',
      timestamp: '2025-07-27T16:20:00',
      messageCount: 31,
      participants: ['Sarah Johnson'],
      complianceFlags: ['confidential']
    },
    {
      id: 4,
      title: 'General Banking Queries',
      mode: 'general',
      timestamp: '2025-07-27T14:15:00',
      messageCount: 12,
      participants: ['Sarah Johnson'],
      complianceFlags: []
    }
  ]);

  const chatModes = [
    {
      id: 'regulatory',
      label: 'Regulatory Compliance',
      icon: 'Shield',
      description: 'Compliance and regulatory guidance',
      color: 'text-error',
      requiresAuth: true,
      auditLevel: 'high'
    },
    {
      id: 'policy',
      label: 'Policy Analysis',
      icon: 'FileText',
      description: 'Policy interpretation and analysis',
      color: 'text-primary',
      requiresAuth: true,
      auditLevel: 'medium'
    },
    {
      id: 'competitive',
      label: 'Competitive Intelligence',
      icon: 'TrendingUp',
      description: 'Market and competitive insights',
      color: 'text-accent',
      requiresAuth: true,
      auditLevel: 'high'
    },
    {
      id: 'general',
      label: 'General Banking',
      icon: 'MessageCircle',
      description: 'General banking assistance',
      color: 'text-text-secondary',
      requiresAuth: false,
      auditLevel: 'low'
    }
  ];

  const handleModeChange = (modeId) => {
    setCurrentMode(modeId);
    // Navigate to chat interface with mode context
    navigate('/chat-interface-dashboard', { state: { mode: modeId } });
  };

  const handleSessionSelect = (session) => {
    setSelectedSession(session);
    navigate('/chat-interface-dashboard', { 
      state: { sessionId: session.id, mode: session.mode } 
    });
  };

  const handleSessionManagement = () => {
    setSessionManagementVisible(true);
    navigate('/chat-session-management');
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return date.toLocaleDateString();
  };

  const getRecentSessions = () => {
    return chatSessions
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(0, 5);
  };

  useEffect(() => {
    const handleKeyboardShortcuts = (e) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'h':
            e.preventDefault();
            setIsCollapsed(!isCollapsed);
            break;
          case 'm':
            e.preventDefault();
            handleSessionManagement();
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyboardShortcuts);
    return () => window.removeEventListener('keydown', handleKeyboardShortcuts);
  }, [isCollapsed]);

  return (
    <>
      {/* Sidebar */}
      <aside 
        className={`fixed left-0 top-16 h-[calc(100vh-4rem)] bg-surface border-r border-subtle z-90 transition-layout ${
          isCollapsed ? 'w-16' : 'w-80'
        } lg:w-80 lg:block ${isCollapsed ? 'lg:w-16' : ''}`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between p-4 border-b border-subtle">
            {!isCollapsed && (
              <h2 className="text-lg font-semibold text-text-primary">
                Chat Workspace
              </h2>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="lg:flex"
            >
              <Icon 
                name={isCollapsed ? "ChevronRight" : "ChevronLeft"} 
                size={16} 
              />
            </Button>
          </div>

          {/* Chat Mode Selector */}
          <div className="p-4 border-b border-subtle">
            {!isCollapsed && (
              <h3 className="text-sm font-medium text-text-secondary mb-3">
                Chat Mode
              </h3>
            )}
            <div className="space-y-1">
              {chatModes.map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => handleModeChange(mode.id)}
                  className={`w-full flex items-center p-3 rounded-lg transition-banking focus-banking ${
                    currentMode === mode.id
                      ? 'bg-primary text-primary-foreground'
                      : 'hover:bg-muted text-text-primary'
                  }`}
                  title={isCollapsed ? mode.label : mode.description}
                >
                  <Icon 
                    name={mode.icon} 
                    size={16} 
                    className={`${isCollapsed ? '' : 'mr-3'} ${
                      currentMode === mode.id ? '' : mode.color
                    }`}
                  />
                  {!isCollapsed && (
                    <div className="flex flex-col items-start flex-1">
                      <span className="text-sm font-medium">{mode.label}</span>
                      <span className="text-xs opacity-75">
                        {mode.description}
                      </span>
                    </div>
                  )}
                  {!isCollapsed && mode.requiresAuth && (
                    <Icon name="Lock" size={12} className="opacity-50" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Recent Sessions */}
          <div className="flex-1 overflow-y-auto">
            <div className="p-4">
              {!isCollapsed && (
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-text-secondary">
                    Recent Sessions
                  </h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSessionManagement}
                    iconName="Settings"
                    iconSize={12}
                    className="text-xs"
                  >
                    Manage
                  </Button>
                </div>
              )}
              
              <div className="space-y-2">
                {getRecentSessions().map((session) => (
                  <button
                    key={session.id}
                    onClick={() => handleSessionSelect(session)}
                    className={`w-full flex items-start p-3 rounded-lg transition-banking focus-banking hover:bg-muted ${
                      selectedSession?.id === session.id ? 'bg-accent/10 border border-accent/20' : ''
                    }`}
                    title={isCollapsed ? session.title : ''}
                  >
                    <div className={`flex-shrink-0 ${isCollapsed ? '' : 'mr-3'}`}>
                      <Icon 
                        name={chatModes.find(m => m.id === session.mode)?.icon || 'MessageCircle'} 
                        size={16} 
                        className="text-text-secondary"
                      />
                    </div>
                    {!isCollapsed && (
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-sm font-medium text-text-primary truncate">
                            {session.title}
                          </h4>
                          {session.complianceFlags.length > 0 && (
                            <Icon 
                              name="AlertTriangle" 
                              size={12} 
                              className="text-warning flex-shrink-0 ml-1"
                            />
                          )}
                        </div>
                        <div className="flex items-center justify-between text-xs text-text-secondary">
                          <span>{session.messageCount} messages</span>
                          <span>{formatTimestamp(session.timestamp)}</span>
                        </div>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-subtle">
            <div className="flex items-center space-x-2">
              {!isCollapsed && (
                <div className="flex-1">
                  <div className="text-xs text-text-secondary">
                    Keyboard shortcuts: Ctrl+H (toggle), Ctrl+M (manage)
                  </div>
                </div>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSessionManagement}
                title="Session Management"
              >
                <Icon name="FolderOpen" size={16} />
              </Button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Offset */}
      <div 
        className={`transition-layout ${
          isCollapsed ? 'lg:ml-16' : 'lg:ml-80'
        }`}
        style={{ minHeight: 'calc(100vh - 4rem)', marginTop: '4rem' }}
      />
    </>
  );
};

export default Sidebar;