import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import ChatInterfaceDashboard from "pages/chat-interface-dashboard";
import ChatSessionManagement from "pages/chat-session-management";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your routes here */}
        <Route path="/" element={<ChatInterfaceDashboard />} />
        <Route path="/chat-interface-dashboard" element={<ChatInterfaceDashboard />} />
        <Route path="/chat-session-management" element={<ChatSessionManagement />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;