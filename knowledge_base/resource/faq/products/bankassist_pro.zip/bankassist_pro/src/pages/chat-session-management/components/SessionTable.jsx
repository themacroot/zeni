import React, { useState, useEffect, useRef, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const SessionTable = ({ 
  sessions, 
  selectedSessions, 
  onSessionSelect, 
  onSessionPreview, 
  onBulkAction,
  onStartRegulatoryChat,
  currentUser 
}) => {
  const [sortConfig, setSortConfig] = useState({
    key: 'timestamp',
    direction: 'desc'
  });
  const [editingSession, setEditingSession] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [selectedRows, setSelectedRows] = useState(new Set());
  const tableRef = useRef(null);

  const getModeIcon = (mode) => {
    const icons = {
      regulatory: 'Shield',
      policy: 'FileText',
      competitive: 'TrendingUp',
      general: 'MessageCircle'
    };
    return icons?.[mode] || 'MessageCircle';
  };

  const getModeColor = (mode) => {
    const colors = {
      regulatory: 'text-error',
      policy: 'text-primary',
      competitive: 'text-accent',
      general: 'text-text-secondary'
    };
    return colors?.[mode] || 'text-text-secondary';
  };

  const getComplianceFlagColor = (flag) => {
    const colors = {
      'high-priority': 'bg-error text-error-foreground',
      'confidential': 'bg-warning text-warning-foreground',
      'audit-required': 'bg-accent text-accent-foreground',
      'regulatory-review': 'bg-primary text-primary-foreground'
    };
    return colors?.[flag] || 'bg-muted text-muted-foreground';
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return date?.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev?.key === key && prev?.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const sortedSessions = React.useMemo(() => {
    if (!sortConfig?.key) return sessions;

    return [...sessions]?.sort((a, b) => {
      let aValue = a?.[sortConfig?.key];
      let bValue = b?.[sortConfig?.key];

      if (sortConfig?.key === 'timestamp') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (aValue < bValue) return sortConfig?.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig?.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [sessions, sortConfig]);

  const handleRowSelect = (sessionId, isSelected) => {
    const newSelected = new Set(selectedRows);
    if (isSelected) {
      newSelected?.add(sessionId);
    } else {
      newSelected?.delete(sessionId);
    }
    setSelectedRows(newSelected);
    onSessionSelect(Array.from(newSelected));
  };

  const handleSelectAll = () => {
    if (selectedRows?.size === sessions?.length) {
      setSelectedRows(new Set());
      onSessionSelect([]);
    } else {
      const allIds = new Set(sessions.map(s => s.id));
      setSelectedRows(allIds);
      onSessionSelect(Array.from(allIds));
    }
  };

  const startEditing = (session) => {
    setEditingSession(session?.id);
    setEditTitle(session?.title);
  };

  const saveEdit = () => {
    // In real app, this would call an API
    console.log('Saving title:', editTitle);
    setEditingSession(null);
    setEditTitle('');
  };

  const cancelEdit = () => {
    setEditingSession(null);
    setEditTitle('');
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!tableRef?.current) return;

      switch (e?.key) {
        case 'j':
          e?.preventDefault();
          // Navigate down
          break;
        case 'k':
          e?.preventDefault();
          // Navigate up
          break;
        case ' ':
          e?.preventDefault();
          // Preview selected session
          break;
        case 'x':
          e?.preventDefault();
          // Toggle selection
          break;
        default:
          break;
      }
    };

    if (tableRef?.current) {
      tableRef?.current?.addEventListener('keydown', handleKeyDown);
      return () => tableRef?.current?.removeEventListener('keydown', handleKeyDown);
    }
  }, []);

  const SortableHeader = ({ label, sortKey, className = "" }) => (
    <th 
      className={`px-4 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer hover:bg-muted transition-banking ${className}`}
      onClick={() => handleSort(sortKey)}
    >
      <div className="flex items-center space-x-1">
        <span>{label}</span>
        {sortConfig?.key === sortKey && (
          <Icon 
            name={sortConfig?.direction === 'asc' ? "ChevronUp" : "ChevronDown"} 
            size={14} 
          />
        )}
      </div>
    </th>
  );

  return (
    <div className="bg-surface h-full flex flex-col" ref={tableRef} tabIndex={0}>
      {/* Table Header with Bulk Actions */}
      {selectedRows?.size > 0 && (
        <div className="p-4 bg-accent/10 border-b border-accent/20">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-text-primary">
              {selectedRows?.size} session{selectedRows?.size !== 1 ? 's' : ''} selected
            </span>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onBulkAction('export', Array.from(selectedRows))}
                iconName="Download"
                iconSize={14}
              >
                Export
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onBulkAction('categorize', Array.from(selectedRows))}
                iconName="Tag"
                iconSize={14}
              >
                Categorize
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onBulkAction('backup', Array.from(selectedRows))}
                iconName="Archive"
                iconSize={14}
              >
                Backup
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => onBulkAction('delete', Array.from(selectedRows))}
                iconName="Trash2"
                iconSize={14}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full">
          <thead className="bg-muted sticky top-0 z-10">
            <tr>
              <th className="px-4 py-3 w-12">
                <input
                  type="checkbox"
                  checked={selectedRows?.size === sessions?.length && sessions?.length > 0}
                  onChange={handleSelectAll}
                  className="rounded border-border focus:ring-ring"
                />
              </th>
              <SortableHeader label="Session Title" sortKey="title" className="min-w-80" />
              <SortableHeader label="Mode" sortKey="mode" className="w-32" />
              <SortableHeader label="Last Activity" sortKey="timestamp" className="w-32" />
              <SortableHeader label="Messages" sortKey="messageCount" className="w-24" />
              <SortableHeader label="Participants" sortKey="participants" className="w-40" />
              {currentUser?.role === 'compliance' && (
                <th className="px-4 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider w-32">
                  Compliance
                </th>
              )}
              {currentUser?.role === 'admin' && (
                <th className="px-4 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider w-24">
                  Storage
                </th>
              )}
              <th className="px-4 py-3 w-32">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {sortedSessions?.map((session, index) => (
              <tr 
                key={session?.id}
                className={`hover:bg-muted/50 transition-banking cursor-pointer ${
                  selectedSessions?.includes(session?.id) ? 'bg-accent/10' : ''
                }`}
                onClick={() => onSessionPreview(session)}
              >
                <td className="px-4 py-4">
                  <input
                    type="checkbox"
                    checked={selectedRows?.has(session?.id)}
                    onChange={(e) => {
                      e?.stopPropagation();
                      handleRowSelect(session?.id, e?.target?.checked);
                    }}
                    className="rounded border-border focus:ring-ring"
                  />
                </td>
                <td className="px-4 py-4">
                  {editingSession === session?.id ? (
                    <div className="flex items-center space-x-2" onClick={(e) => e?.stopPropagation()}>
                      <Input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e?.target?.value)}
                        className="text-sm"
                        onKeyDown={(e) => {
                          if (e?.key === 'Enter') saveEdit();
                          if (e?.key === 'Escape') cancelEdit();
                        }}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={saveEdit}
                      >
                        <Icon name="Check" size={14} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={cancelEdit}
                      >
                        <Icon name="X" size={14} />
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-text-primary truncate max-w-xs">
                        {session?.title}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e?.stopPropagation();
                          startEditing(session);
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Icon name="Edit2" size={12} />
                      </Button>
                    </div>
                  )}
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={getModeIcon(session?.mode)} 
                      size={16} 
                      className={getModeColor(session?.mode)}
                    />
                    <span className="text-sm text-text-primary capitalize">
                      {session?.mode}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className="text-sm text-text-secondary">
                    {formatTimestamp(session?.timestamp)}
                  </span>
                </td>
                <td className="px-4 py-4">
                  <span className="text-sm text-text-primary">
                    {session?.messageCount}
                  </span>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center space-x-1">
                    {session?.participants?.slice(0, 2)?.map((participant, idx) => (
                      <div
                        key={idx}
                        className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-xs text-primary-foreground font-medium"
                        title={participant}
                      >
                        {participant?.split(' ')?.map(n => n?.[0])?.join('')}
                      </div>
                    ))}
                    {session?.participants?.length > 2 && (
                      <span className="text-xs text-text-secondary">
                        +{session?.participants?.length - 2}
                      </span>
                    )}
                  </div>
                </td>
                {currentUser?.role === 'compliance' && (
                  <td className="px-4 py-4">
                    <div className="flex flex-wrap gap-1">
                      {session?.complianceFlags?.map((flag, idx) => (
                        <span
                          key={idx}
                          className={`px-2 py-1 text-xs rounded-full ${getComplianceFlagColor(flag)}`}
                        >
                          {flag?.replace('-', ' ')}
                        </span>
                      ))}
                    </div>
                  </td>
                )}
                {currentUser?.role === 'admin' && (
                  <td className="px-4 py-4">
                    <div className="text-xs text-text-secondary">
                      {(Math.random() * 10 + 1)?.toFixed(1)} MB
                    </div>
                  </td>
                )}
                <td className="px-4 py-4">
                  <div className="flex items-center space-x-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e?.stopPropagation();
                        onSessionPreview(session);
                      }}
                      title="Preview"
                    >
                      <Icon name="Eye" size={14} />
                    </Button>
                    {session?.mode === 'regulatory' && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e?.stopPropagation();
                          onStartRegulatoryChat?.(session);
                        }}
                        title="Continue Regulatory Chat"
                        className="text-error hover:text-error"
                      >
                        <Icon name="Shield" size={14} />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e?.stopPropagation();
                        onBulkAction('export', [session?.id]);
                      }}
                      title="Export"
                    >
                      <Icon name="Download" size={14} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Keyboard Shortcuts Help */}
      <div className="p-2 border-t border-subtle bg-muted/30">
        <div className="text-xs text-text-secondary text-center">
          Keyboard: J/K (navigate) • Space (preview) • X (select) • Ctrl+A (select all) • Ctrl+R (regulatory chat)
        </div>
      </div>
    </div>
  );
};

export default SessionTable;