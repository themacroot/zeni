import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const SessionPreview = ({ session, onExport, onClose }) => {
  const [exportFormat, setExportFormat] = useState('json');
  const [showMetadata, setShowMetadata] = useState(true);

  if (!session) {
    return (
      <div className="bg-surface h-full flex items-center justify-center">
        <div className="text-center">
          <Icon name="MessageSquare" size={48} className="text-text-secondary mx-auto mb-4" />
          <p className="text-text-secondary">Select a session to preview</p>
        </div>
      </div>
    );
  }

  const exportFormatOptions = [
    { value: 'json', label: 'JSON Format' },
    { value: 'csv', label: 'CSV Format' },
    { value: 'pdf', label: 'PDF Report' },
    { value: 'txt', label: 'Plain Text' }
  ];

  const getModeIcon = (mode) => {
    const icons = {
      regulatory: 'Shield',
      policy: 'FileText',
      competitive: 'TrendingUp',
      general: 'MessageCircle'
    };
    return icons[mode] || 'MessageCircle';
  };

  const getModeColor = (mode) => {
    const colors = {
      regulatory: 'text-error',
      policy: 'text-primary',
      competitive: 'text-accent',
      general: 'text-text-secondary'
    };
    return colors[mode] || 'text-text-secondary';
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleString('en-IN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const mockMessages = [
    {
      id: 1,
      sender: 'Sarah Johnson',
      content: 'What are the latest RBI guidelines for digital lending platforms?',
      timestamp: new Date(session.timestamp),
      type: 'user'
    },
    {
      id: 2,
      sender: 'BankAssist Pro',
      content: `Based on the latest RBI Master Direction on Digital Lending (September 2022), here are the key guidelines:\n\n1. **Lending Service Provider (LSP) Regulations:**\n   - All digital lending must be done directly by regulated entities\n   - LSPs cannot hold borrower funds\n   - Clear disclosure of all fees and charges\n\n2. **Data Privacy & Security:**\n   - Explicit consent for data collection\n   - Data localization requirements\n   - Automated processing limitations\n\n3. **Fair Practices:**\n   - Cooling-off period for borrowers\n   - Standardized loan agreements\n   - Grievance redressal mechanisms`,
      timestamp: new Date(session.timestamp + 30000),
      type: 'assistant',
      sources: ['RBI Master Direction - Digital Lending', 'RBI Circular DOR.STR.REC.51/21.04.048/2022-23']
    },
    {
      id: 3,
      sender: 'Sarah Johnson',
      content: 'Are there any specific compliance requirements for mobile app-based lending?',
      timestamp: new Date(session.timestamp + 120000),
      type: 'user'
    },
    {
      id: 4,
      sender: 'BankAssist Pro',
      content: `Yes, mobile app-based lending has additional compliance requirements:\n\n**App Store Compliance:**\n- Apps must be published only by regulated entities or their authorized partners\n- Clear identification of the lending entity\n- Proper app permissions and data access controls\n\n**User Interface Requirements:**\n- Transparent fee disclosure before loan approval\n- Easy access to loan terms and conditions\n- Clear repayment schedules and options\n\n**Technical Standards:**\n- End-to-end encryption for sensitive data\n- Secure authentication mechanisms\n- Regular security audits and penetration testing`,
      timestamp: new Date(session.timestamp + 180000),
      type: 'assistant',
      sources: ['RBI Guidelines on Mobile Banking', 'IT Framework for NBFC-P2P']
    }
  ];

  const handleExport = () => {
    onExport(session.id, exportFormat);
  };

  return (
    <div className="bg-surface h-full flex flex-col border-l border-subtle">
      {/* Header */}
      <div className="p-4 border-b border-subtle">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <Icon 
                name={getModeIcon(session.mode)} 
                size={20} 
                className={getModeColor(session.mode)}
              />
              <h2 className="text-lg font-semibold text-text-primary">
                Session Preview
              </h2>
            </div>
            <h3 className="text-sm font-medium text-text-primary mb-1">
              {session.title}
            </h3>
            <p className="text-xs text-text-secondary">
              {formatTimestamp(session.timestamp)} • {session.messageCount} messages
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={16} />
          </Button>
        </div>

        {/* Export Controls */}
        <div className="flex items-center space-x-2">
          <Select
            options={exportFormatOptions}
            value={exportFormat}
            onChange={setExportFormat}
            className="flex-1"
          />
          <Button
            variant="outline"
            size="sm"
            onClick={handleExport}
            iconName="Download"
            iconSize={14}
          >
            Export
          </Button>
        </div>
      </div>

      {/* Session Metadata */}
      {showMetadata && (
        <div className="p-4 border-b border-subtle bg-muted/30">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-medium text-text-primary">
              Session Metadata
            </h4>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowMetadata(false)}
              iconName="ChevronUp"
              iconSize={14}
            >
              Hide
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-text-secondary">Mode:</span>
              <span className="ml-2 text-text-primary capitalize">{session.mode}</span>
            </div>
            <div>
              <span className="text-text-secondary">Messages:</span>
              <span className="ml-2 text-text-primary">{session.messageCount}</span>
            </div>
            <div>
              <span className="text-text-secondary">Participants:</span>
              <span className="ml-2 text-text-primary">{session.participants.join(', ')}</span>
            </div>
            <div>
              <span className="text-text-secondary">Created:</span>
              <span className="ml-2 text-text-primary">{formatTimestamp(session.timestamp)}</span>
            </div>
            {session.complianceFlags.length > 0 && (
              <div className="col-span-2">
                <span className="text-text-secondary">Compliance Flags:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {session.complianceFlags.map((flag, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-1 text-xs rounded-full bg-warning text-warning-foreground"
                    >
                      {flag.replace('-', ' ')}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {!showMetadata && (
        <div className="p-2 border-b border-subtle">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowMetadata(true)}
            iconName="ChevronDown"
            iconSize={14}
            className="w-full"
          >
            Show Metadata
          </Button>
        </div>
      )}

      {/* Message Preview */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-4">
          {mockMessages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user' ?'bg-primary text-primary-foreground' :'bg-muted text-text-primary'
                }`}
              >
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-xs font-medium opacity-75">
                    {message.sender}
                  </span>
                  <span className="text-xs opacity-50">
                    {message.timestamp.toLocaleTimeString('en-IN', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
                <div className="text-sm whitespace-pre-line">
                  {message.content}
                </div>
                {message.sources && (
                  <div className="mt-2 pt-2 border-t border-current/20">
                    <div className="text-xs opacity-75 mb-1">Sources:</div>
                    {message.sources.map((source, idx) => (
                      <div key={idx} className="text-xs opacity-60">
                        • {source}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Preview Footer */}
      <div className="p-4 border-t border-subtle bg-muted/30">
        <div className="flex items-center justify-between text-xs text-text-secondary">
          <span>Preview showing {mockMessages.length} of {session.messageCount} messages</span>
          <Button
            variant="ghost"
            size="sm"
            iconName="ExternalLink"
            iconSize={12}
            className="text-xs"
          >
            Open Full Session
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SessionPreview;