import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChatMessage = ({ 
  message, 
  isStreaming = false, 
  onFeedback, 
  onCopy, 
  onShare,
  showAvatar = true 
}) => {
  const [feedback, setFeedback] = useState(message.feedback || null);
  const [showActions, setShowActions] = useState(false);
  const [copied, setCopied] = useState(false);
  const messageRef = useRef(null);

  const isUser = message.sender === 'user';
  const isSystem = message.sender === 'system';

  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [copied]);

  const handleFeedback = (type) => {
    const newFeedback = feedback === type ? null : type;
    setFeedback(newFeedback);
    onFeedback?.(message.id, newFeedback);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      onCopy?.(message.id);
    } catch (error) {
      console.error('Failed to copy message:', error);
    }
  };

  const handleShare = () => {
    onShare?.(message);
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const messageVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { duration: 0.3, ease: "easeOut" }
    }
  };

  return (
    <motion.div
      ref={messageRef}
      variants={messageVariants}
      initial="hidden"
      animate="visible"
      className={`flex items-start space-x-3 mb-6 ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      {/* Avatar */}
      {showAvatar && (
        <div className={`flex-shrink-0 ${isUser ? 'ml-3' : 'mr-3'}`}>
          {isUser ? (
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-sm font-semibold text-primary-foreground">
                SJ
              </span>
            </div>
          ) : isSystem ? (
            <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
              <Icon name="Bot" size={16} color="white" />
            </div>
          ) : (
            <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
              <Icon name="Building2" size={16} color="white" />
            </div>
          )}
        </div>
      )}

      {/* Message Card */}
      <div className={`flex-1 max-w-4xl ${isUser ? 'flex justify-end' : ''}`}>
        <div className={`relative ${
          isUser 
            ? 'bg-primary text-primary-foreground rounded-2xl rounded-tr-md' 
            : 'bg-card border border-subtle rounded-2xl rounded-tl-md'
        } p-4 elevation-1`}>
          
          {/* Message Header */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className={`text-sm font-semibold ${
                isUser ? 'text-primary-foreground' : 'text-text-primary'
              }`}>
                {isUser ? 'You' : isSystem ? 'BankAssist Pro' : 'Assistant'}
              </span>
              {message.mode && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  isUser 
                    ? 'bg-primary-foreground/20 text-primary-foreground' 
                    : 'bg-muted text-text-secondary'
                }`}>
                  {message.mode}
                </span>
              )}
            </div>
            <span className={`text-xs ${
              isUser ? 'text-primary-foreground/70' : 'text-text-secondary'
            }`}>
              {formatTimestamp(message.timestamp)}
            </span>
          </div>

          {/* Message Content */}
          <div className={`prose prose-sm max-w-none ${
            isUser ? 'prose-invert' : ''
          }`}>
            {isStreaming ? (
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span className="text-sm opacity-70">Thinking...</span>
              </div>
            ) : (
              <div className="whitespace-pre-wrap leading-relaxed">
                {message.content}
              </div>
            )}
          </div>

          {/* Source Attribution */}
          {message.sources && message.sources.length > 0 && (
            <div className="mt-3 pt-3 border-t border-subtle/20">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="FileText" size={14} className="text-text-secondary" />
                <span className="text-xs font-medium text-text-secondary">Sources:</span>
              </div>
              <div className="space-y-1">
                {message.sources.map((source, index) => (
                  <button
                    key={index}
                    className="text-xs text-accent hover:text-accent/80 transition-colors block"
                    onClick={() => window.open(source.url, '_blank')}
                  >
                    {source.title}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Message Actions */}
          {!isUser && (showActions || feedback) && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center justify-between mt-3 pt-3 border-t border-subtle/20"
            >
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="xs"
                  onClick={() => handleFeedback('up')}
                  iconName="ThumbsUp"
                  iconSize={14}
                  className={`${feedback === 'up' ? 'text-success bg-success/10' : 'text-text-secondary'}`}
                />
                <Button
                  variant="ghost"
                  size="xs"
                  onClick={() => handleFeedback('down')}
                  iconName="ThumbsDown"
                  iconSize={14}
                  className={`${feedback === 'down' ? 'text-error bg-error/10' : 'text-text-secondary'}`}
                />
              </div>
              
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="xs"
                  onClick={handleCopy}
                  iconName={copied ? "Check" : "Copy"}
                  iconSize={14}
                  className="text-text-secondary"
                  title={copied ? "Copied!" : "Copy message"}
                />
                <Button
                  variant="ghost"
                  size="xs"
                  onClick={handleShare}
                  iconName="Share"
                  iconSize={14}
                  className="text-text-secondary"
                  title="Share message"
                />
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default ChatMessage;