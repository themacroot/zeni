import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const BulkOperationsToolbar = ({ 
  selectedCount, 
  onBulkAction, 
  onClearSelection,
  totalSessions,
  currentUser 
}) => {
  const [showConfirmDialog, setShowConfirmDialog] = useState(null);
  const [exportFormat, setExportFormat] = useState('json');
  const [categoryAction, setCategoryAction] = useState('');

  const exportOptions = [
    { value: 'json', label: 'JSON Format' },
    { value: 'csv', label: 'CSV Spreadsheet' },
    { value: 'pdf', label: 'PDF Report' },
    { value: 'txt', label: 'Plain Text' }
  ];

  const categoryOptions = [
    { value: 'high-priority', label: 'High Priority' },
    { value: 'archived', label: 'Archived' },
    { value: 'training-material', label: 'Training Material' },
    { value: 'compliance-review', label: 'Compliance Review' },
    { value: 'policy-reference', label: 'Policy Reference' }
  ];

  const handleBulkAction = (action, options = {}) => {
    if (action === 'delete') {
      setShowConfirmDialog('delete');
      return;
    }
    
    if (action === 'export') {
      onBulkAction(action, { format: exportFormat, ...options });
      return;
    }

    if (action === 'categorize' && categoryAction) {
      onBulkAction(action, { category: categoryAction, ...options });
      setCategoryAction('');
      return;
    }

    onBulkAction(action, options);
  };

  const confirmDelete = () => {
    onBulkAction('delete');
    setShowConfirmDialog(null);
  };

  const getStorageEstimate = () => {
    // Mock calculation based on selected sessions
    const avgSizePerSession = 2.5; // MB
    return (selectedCount * avgSizePerSession).toFixed(1);
  };

  if (selectedCount === 0) {
    return null;
  }

  return (
    <>
      <div className="bg-accent/10 border-b border-accent/20 p-4">
        <div className="flex items-center justify-between">
          {/* Selection Info */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Icon name="CheckSquare" size={16} className="text-accent" />
              <span className="text-sm font-medium text-text-primary">
                {selectedCount.toLocaleString()} of {totalSessions.toLocaleString()} sessions selected
              </span>
            </div>
            <div className="text-xs text-text-secondary">
              Est. size: {getStorageEstimate()} MB
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearSelection}
              iconName="X"
              iconSize={14}
              className="text-xs"
            >
              Clear Selection
            </Button>
          </div>

          {/* Bulk Actions */}
          <div className="flex items-center space-x-2">
            {/* Export Actions */}
            <div className="flex items-center space-x-1 border-r border-accent/20 pr-3">
              <Select
                options={exportOptions}
                value={exportFormat}
                onChange={setExportFormat}
                className="w-32"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction('export')}
                iconName="Download"
                iconSize={14}
              >
                Export
              </Button>
            </div>

            {/* Categorization */}
            <div className="flex items-center space-x-1 border-r border-accent/20 pr-3">
              <Select
                options={categoryOptions}
                value={categoryAction}
                onChange={setCategoryAction}
                placeholder="Select category..."
                className="w-40"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction('categorize')}
                disabled={!categoryAction}
                iconName="Tag"
                iconSize={14}
              >
                Categorize
              </Button>
            </div>

            {/* Management Actions */}
            <div className="flex items-center space-x-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBulkAction('backup')}
                iconName="Archive"
                iconSize={14}
                title="Create backup of selected sessions"
              >
                Backup
              </Button>

              {currentUser?.role === 'admin' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction('migrate')}
                  iconName="Database"
                  iconSize={14}
                  title="Migrate to long-term storage"
                >
                  Migrate
                </Button>
              )}

              <Button
                variant="destructive"
                size="sm"
                onClick={() => handleBulkAction('delete')}
                iconName="Trash2"
                iconSize={14}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>

        {/* Progress Indicator for Bulk Operations */}
        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-text-secondary">
            <span>
              Bulk operations support up to 1,000 sessions simultaneously
            </span>
            <span>
              {selectedCount > 1000 && (
                <span className="text-warning">
                  Selection exceeds limit. Only first 1,000 will be processed.
                </span>
              )}
            </span>
          </div>
        </div>
      </div>

      {/* Confirmation Dialog */}
      {showConfirmDialog === 'delete' && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-100">
          <div className="bg-surface rounded-lg p-6 max-w-md w-full mx-4 elevation-3">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-error/10 rounded-full flex items-center justify-center">
                <Icon name="AlertTriangle" size={20} className="text-error" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-text-primary">
                  Confirm Deletion
                </h3>
                <p className="text-sm text-text-secondary">
                  This action cannot be undone
                </p>
              </div>
            </div>

            <div className="mb-6">
              <p className="text-sm text-text-primary mb-2">
                You are about to permanently delete {selectedCount} session{selectedCount !== 1 ? 's' : ''}:
              </p>
              <div className="bg-muted rounded-lg p-3">
                <ul className="text-xs text-text-secondary space-y-1">
                  <li>• All conversation history will be lost</li>
                  <li>• Associated metadata will be removed</li>
                  <li>• Compliance audit trails will be preserved separately</li>
                  <li>• This action is logged for security purposes</li>
                </ul>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowConfirmDialog(null)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={confirmDelete}
                iconName="Trash2"
                iconSize={14}
              >
                Delete {selectedCount} Session{selectedCount !== 1 ? 's' : ''}
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BulkOperationsToolbar;