import React, { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import Header from '../../components/ui/Header';
import ChatSidebar from './components/ChatSidebar';
import ChatToolbar from './components/ChatToolbar';
import ChatArea from './components/ChatArea';
import ChatInput from './components/ChatInput';

const ChatInterfaceDashboard = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // State management
  const [currentMode, setCurrentMode] = useState('general-chat');
  const [currentSession, setCurrentSession] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Mock sessions data
  const [sessions] = useState([
    {
      id: 1,
      title: 'RBI Circular - Digital Lending Guidelines',
      mode: 'rbi-circular',
      timestamp: '2025-07-28T09:30:00',
      messageCount: 24,
      isActive: true,
      messages: [
        {
          id: 1,
          sender: 'user',
          content: 'What are the key compliance requirements for digital lending platforms according to the latest RBI circular?',
          timestamp: '2025-07-28T09:30:00',
          mode: 'rbi-circular'
        },
        {
          id: 2,
          sender: 'assistant',
          content: `Based on the latest RBI circular on digital lending guidelines, here are the key compliance requirements for digital lending platforms:\n\n**1. Fair Practices Code**\n- Transparent disclosure of all charges, fees, and interest rates\n- Clear communication in local language\n- Proper grievance redressal mechanism\n\n**2. Data Privacy & Security**\n- Explicit consent for data collection and usage\n- Data localization requirements\n- Robust cybersecurity measures\n\n**3. Lending Standards**\n- Proper credit assessment mechanisms\n- Reasonable pricing policies\n- No excessive or hidden charges\n\n**4. Customer Protection**\n- Cooling-off period for borrowers\n- Right to prepayment without penalty\n- Protection against harassment\n\n**5. Regulatory Reporting**\n- Regular submission of operational data\n- Compliance with AML/CFT norms\n- Audit trail maintenance`,
          timestamp: '2025-07-28T09:31:30',
          mode: 'rbi-circular',
          sources: [
            {
              title: 'RBI Circular - Guidelines on Digital Lending',
              url: 'https://rbi.org.in/Scripts/BS_CircularIndexDisplay.aspx'
            }
          ],
          feedback: null
        }
      ]
    },
    {
      id: 2,
      title: 'Internal Policy - KYC Updates',
      mode: 'internal-circular',
      timestamp: '2025-07-28T08:45:00',
      messageCount: 18,
      isActive: false,
      messages: []
    }
  ]);

  // Initialize session from route state or default
  useEffect(() => {
    const stateMode = location.state?.mode;
    const stateSessionId = location.state?.sessionId;
    
    if (stateMode) {
      setCurrentMode(stateMode);
    }
    
    if (stateSessionId) {
      const session = sessions.find(s => s.id === stateSessionId);
      if (session) {
        setCurrentSession(session);
        setMessages(session.messages || []);
      }
    } else if (sessions.length > 0) {
      // Default to first active session
      const activeSession = sessions.find(s => s.isActive) || sessions[0];
      setCurrentSession(activeSession);
      setMessages(activeSession.messages || []);
      setCurrentMode(activeSession.mode);
    }
  }, [location.state, sessions]);

  // Handle mode change
  const handleModeChange = useCallback((newMode) => {
    setCurrentMode(newMode);
    // Create new session for mode change
    handleNewChat(newMode);
  }, []);

  // Handle session selection
  const handleSessionSelect = useCallback((session) => {
    setCurrentSession(session);
    setMessages(session.messages || []);
    setCurrentMode(session.mode);
  }, []);

  // Handle new chat creation
  const handleNewChat = useCallback((mode = currentMode) => {
    const newSession = {
      id: Date.now(),
      title: 'New Chat',
      mode: mode,
      timestamp: new Date().toISOString(),
      messageCount: 0,
      isActive: true,
      messages: []
    };
    
    setCurrentSession(newSession);
    setMessages([]);
    setCurrentMode(mode);
  }, [currentMode]);

  // Handle message sending
  const handleSendMessage = useCallback(async (messageContent) => {
    if (!messageContent.trim() || isStreaming) return;

    const userMessage = {
      id: Date.now(),
      sender: 'user',
      content: messageContent,
      timestamp: new Date().toISOString(),
      mode: currentMode
    };

    // Add user message immediately
    setMessages(prev => [...prev, userMessage]);
    setIsStreaming(true);

    try {
      // Simulate API call with realistic delay
      await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1000));

      // Generate mock response based on mode
      const assistantMessage = generateMockResponse(messageContent, currentMode);
      
      setMessages(prev => [...prev, assistantMessage]);
      
      // Update session title if it's the first message
      if (currentSession && currentSession.title === 'New Chat') {
        const updatedSession = {
          ...currentSession,
          title: generateSessionTitle(messageContent),
          messageCount: 2
        };
        setCurrentSession(updatedSession);
      }
      
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Add error message
      const errorMessage = {
        id: Date.now() + 1,
        sender: 'system',
        content: 'Sorry, I encountered an error while processing your request. Please try again.',
        timestamp: new Date().toISOString(),
        mode: currentMode
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsStreaming(false);
    }
  }, [currentMode, currentSession, isStreaming]);

  // Generate mock response based on mode and content
  const generateMockResponse = (userMessage, mode) => {
    const responses = {
      'rbi-circular': `Based on the latest RBI guidelines and circulars, here's the relevant information:\n\n${generateRBIResponse(userMessage)}`,
      'internal-circular': `According to our internal banking policies and procedures:\n\n${generateInternalResponse(userMessage)}`,
      'peer-comparison': `Here's a competitive analysis based on current market data:\n\n${generateCompetitiveResponse(userMessage)}`,
      'general-chat': `Here's the information you requested:\n\n${generateGeneralResponse(userMessage)}`
    };

    return {
      id: Date.now() + 1,
      sender: 'assistant',
      content: responses[mode] || responses['general-chat'],
      timestamp: new Date().toISOString(),
      mode: mode,
      sources: generateMockSources(mode),
      feedback: null
    };
  };

  const generateRBIResponse = (message) => {
    return `**Regulatory Framework:**\n- Compliance with current RBI norms is mandatory\n- Regular monitoring and reporting required\n- Adherence to Basel III guidelines\n\n**Key Requirements:**\n- Capital adequacy ratios must be maintained\n- Risk management protocols to be followed\n- Customer protection measures implemented\n\n**Implementation Timeline:**\n- Immediate compliance required for critical aspects\n- Phased implementation for complex requirements\n- Regular review and updates as per RBI notifications`;
  };

  const generateInternalResponse = (message) => {
    return `**Policy Guidelines:**\n- Follow established internal procedures\n- Ensure proper documentation and approval workflows\n- Maintain audit trail for all transactions\n\n**Operational Requirements:**\n- Staff training and certification mandatory\n- Regular policy updates and communication\n- Exception handling procedures to be followed\n\n**Compliance Monitoring:**\n- Monthly compliance reports required\n- Internal audit reviews scheduled quarterly\n- Corrective actions to be implemented promptly`;
  };

  const generateCompetitiveResponse = (message) => {
    return `**Market Position:**\n- Our current offerings are competitive in the market\n- Key differentiators include customer service and digital features\n- Pricing strategy aligns with market standards\n\n**Peer Comparison:**\n- HDFC Bank: Strong digital platform, premium pricing\n- ICICI Bank: Comprehensive product suite, aggressive marketing\n- SBI: Market leader, extensive branch network\n\n**Strategic Recommendations:**\n- Focus on digital innovation and customer experience\n- Enhance mobile banking capabilities\n- Develop niche products for specific segments`;
  };

  const generateGeneralResponse = (message) => {
    return `**Banking Information:**\n- Standard banking procedures apply\n- Customer verification and documentation required\n- Processing times vary based on product type\n\n**Service Details:**\n- Multiple channels available for service delivery\n- Digital and physical touchpoints integrated\n- 24/7 customer support for critical services\n\n**Additional Support:**\n- Detailed product information available\n- Personalized assistance through relationship managers\n- Regular updates on new products and services`;
  };

  const generateMockSources = (mode) => {
    const sources = {
      'rbi-circular': [
        { title: 'RBI Master Circular - Banking Regulations', url: 'https://rbi.org.in' },
        { title: 'Basel III Implementation Guidelines', url: 'https://rbi.org.in' }
      ],
      'internal-circular': [
        { title: 'Internal Policy Manual - Section 4.2', url: '#' },
        { title: 'Operational Guidelines Document', url: '#' }
      ],
      'peer-comparison': [
        { title: 'Banking Industry Report 2025', url: '#' },
        { title: 'Competitive Analysis Dashboard', url: '#' }
      ],
      'general-chat': [
        { title: 'Banking Knowledge Base', url: '#' },
        { title: 'Customer Service Guidelines', url: '#' }
      ]
    };
    
    return sources[mode] || sources['general-chat'];
  };

  const generateSessionTitle = (firstMessage) => {
    const words = firstMessage.split(' ').slice(0, 6).join(' ');
    return words.length > 50 ? words.substring(0, 47) + '...' : words;
  };

  // Handle message feedback
  const handleMessageFeedback = useCallback((messageId, feedback) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, feedback } : msg
    ));
  }, []);

  // Handle message copy
  const handleMessageCopy = useCallback((messageId) => {
    // Copy functionality handled in ChatMessage component
    console.log('Message copied:', messageId);
  }, []);

  // Handle message share
  const handleMessageShare = useCallback((message) => {
    if (navigator.share) {
      navigator.share({
        title: 'BankAssist Pro - Chat Message',
        text: message.content,
        url: window.location.href
      });
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(message.content);
    }
  }, []);

  // Handle session export
  const handleSessionExport = useCallback((session, format) => {
    console.log('Exporting session:', session.id, 'as', format);
    // Export functionality would be implemented here
  }, []);

  // Handle session settings
  const handleSessionSettings = useCallback(() => {
    console.log('Opening session settings for:', currentSession?.id);
    // Session settings modal would be opened here
  }, [currentSession]);

  // Handle sidebar toggle
  const handleSidebarToggle = useCallback(() => {
    setIsSidebarCollapsed(prev => !prev);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyboardShortcuts = (e) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case '/':
            e.preventDefault();
            // Focus search in sidebar
            break;
          case 'n':
            e.preventDefault();
            handleNewChat();
            break;
          case 'h':
            e.preventDefault();
            handleSidebarToggle();
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyboardShortcuts);
    return () => window.removeEventListener('keydown', handleKeyboardShortcuts);
  }, [handleNewChat, handleSidebarToggle]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="flex">
        {/* Sidebar */}
        <ChatSidebar
          currentSessionId={currentSession?.id}
          onSessionSelect={handleSessionSelect}
          onNewChat={handleNewChat}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleSidebarToggle}
        />

        {/* Main Chat Interface */}
        <div className={`flex-1 flex flex-col transition-all duration-300 ${
          isSidebarCollapsed ? 'ml-16' : 'ml-80'
        }`}>
          {/* Chat Toolbar */}
          <ChatToolbar
            currentMode={currentMode}
            onModeChange={handleModeChange}
            currentSession={currentSession}
            onExportSession={handleSessionExport}
            onSessionSettings={handleSessionSettings}
            disabled={isStreaming}
          />

          {/* Chat Area */}
          <ChatArea
            messages={messages}
            isStreaming={isStreaming}
            onMessageFeedback={handleMessageFeedback}
            onMessageCopy={handleMessageCopy}
            onMessageShare={handleMessageShare}
            currentSession={currentSession}
            autoScroll={true}
          />

          {/* Chat Input */}
          <ChatInput
            onSendMessage={handleSendMessage}
            disabled={isLoading}
            isStreaming={isStreaming}
            currentMode={currentMode}
            placeholder={`Ask about ${currentMode.replace('-', ' ')}...`}
          />
        </div>
      </div>
    </div>
  );
};

export default ChatInterfaceDashboard;