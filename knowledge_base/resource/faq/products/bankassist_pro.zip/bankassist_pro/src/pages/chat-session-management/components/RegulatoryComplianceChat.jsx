import React, { useState, useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import rbiApiService from '../../../services/rbiApiService';

const RegulatoryComplianceChat = ({ isVisible, onClose, sessionData = null }) => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [apiConfigured, setApiConfigured] = useState(false);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Initialize component
  useEffect(() => {
    setApiConfigured(rbiApiService?.isConfigured());
    
    // Load existing session data if provided
    if (sessionData?.messages) {
      setMessages(sessionData?.messages);
    }
    
    // Focus input when visible
    if (isVisible && inputRef?.current) {
      inputRef?.current?.focus();
    }
  }, [isVisible, sessionData]);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!inputText?.trim() || isLoading) return;
    if (!apiConfigured) {
      setError('RBI API is not configured. Please check environment variables.');
      return;
    }

    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: inputText?.trim(),
      timestamp: new Date()?.toISOString()
    };

    // Add user message to chat
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);
    setError(null);

    try {
      // Prepare context for API call
      const context = [...messages, userMessage]?.map(msg => ({
        role: msg?.role,
        content: msg?.content
      }));

      console.log('Sending to RBI API:', { context, chat_type: 'rbi' });

      // Call RBI API
      const apiResponse = await rbiApiService?.queryRegulatory(context, 'rbi');

      if (apiResponse?.success && apiResponse?.data?.response?.answer) {
        const assistantMessage = {
          id: Date.now() + 1,
          role: 'assistant',
          content: apiResponse?.data?.response?.answer,
          timestamp: new Date()?.toISOString(),
          references: apiResponse?.data?.response?.references || [],
          apiMetadata: {
            requestId: apiResponse?.data?.requestId,
            processingTime: apiResponse?.data?.processingTime
          }
        };

        setMessages(prev => [...prev, assistantMessage]);
        
        // Save to session storage for persistence
        const sessionKey = `rbi_session_${sessionData?.id || 'current'}`;
        const sessionToSave = {
          id: sessionData?.id || Date.now(),
          messages: [...messages, userMessage, assistantMessage],
          lastUpdated: new Date()?.toISOString(),
          mode: 'regulatory'
        };
        
        localStorage.setItem(sessionKey, JSON.stringify(sessionToSave));
        
      } else {
        throw new Error(apiResponse.error?.message || 'Failed to get response from RBI API');
      }
    } catch (err) {
      console.error('Error calling RBI API:', err);
      
      const errorMessage = {
        id: Date.now() + 1,
        role: 'system',
        content: `Error: ${err?.message || 'Failed to connect to RBI API. Please check your connection and try again.'}`,
        timestamp: new Date()?.toISOString(),
        isError: true
      };
      
      setMessages(prev => [...prev, errorMessage]);
      setError(err?.message);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    if (window.confirm('Are you sure you want to clear this regulatory compliance session?')) {
      setMessages([]);
      setError(null);
      
      // Clear from localStorage
      if (sessionData?.id) {
        localStorage.removeItem(`rbi_session_${sessionData?.id}`);
      }
    }
  };

  const exportChat = () => {
    const exportData = {
      sessionId: sessionData?.id || Date.now(),
      title: sessionData?.title || 'Regulatory Compliance Session',
      messages: messages,
      exportedAt: new Date()?.toISOString(),
      mode: 'regulatory'
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rbi_session_${sessionData?.id || Date.now()}.json`;
    document.body?.appendChild(a);
    a?.click();
    document.body?.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const renderMessage = (message) => {
    const isUser = message?.role === 'user';
    const isSystem = message?.role === 'system';
    const isError = message?.isError;

    return (
      <div
        key={message?.id}
        className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}
      >
        <div className={`max-w-3xl ${isUser ? 'order-2' : 'order-1'}`}>
          {!isUser && (
            <div className="flex items-center mb-2">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-2 ${
                isSystem ? 'bg-warning' : 'bg-primary'
              }`}>
                <Icon 
                  name={isSystem ? 'AlertTriangle' : 'Shield'} 
                  size={12} 
                  className="text-white" 
                />
              </div>
              <span className="text-xs text-text-secondary">
                {isSystem ? 'System' : 'RBI Assistant'}
              </span>
            </div>
          )}
          
          <div className={`p-4 rounded-lg ${
            isUser 
              ? 'bg-primary text-primary-foreground ml-4' 
              : isError
                ? 'bg-error/10 text-error border border-error/20 mr-4' :'bg-muted text-text-primary mr-4'
          }`}>
            <div className="text-sm whitespace-pre-wrap">
              {message?.content}
            </div>
            
            {message?.references && message?.references?.length > 0 && (
              <div className="mt-3 pt-3 border-t border-border/20">
                <div className="text-xs font-medium text-text-secondary mb-2">
                  References:
                </div>
                {message?.references?.map((ref, idx) => (
                  <div key={idx} className="text-xs bg-surface/50 p-2 rounded mb-1">
                    <div className="font-medium">{ref?.title}</div>
                    <div className="text-text-secondary">
                      Source: {ref?.source} | Relevance: {(ref?.score * 100)?.toFixed(1)}%
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            <div className="text-xs text-text-secondary/70 mt-2">
              {new Date(message.timestamp)?.toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-surface rounded-lg shadow-xl w-full max-w-4xl h-[80vh] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon name="Shield" size={20} className="text-error" />
            <div>
              <h2 className="text-lg font-semibold text-text-primary">
                Regulatory Compliance Chat
              </h2>
              <p className="text-sm text-text-secondary">
                RBI Digital Payment Security Controls Query
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {!apiConfigured && (
              <div className="flex items-center space-x-1 text-warning">
                <Icon name="AlertTriangle" size={16} />
                <span className="text-xs">API Not Configured</span>
              </div>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={exportChat}
              iconName="Download"
              iconSize={16}
              disabled={messages?.length === 0}
            >
              Export
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={clearChat}
              iconName="Trash2"
              iconSize={16}
              disabled={messages?.length === 0}
            >
              Clear
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              iconName="X"
              iconSize={16}
            >
              Close
            </Button>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4">
          {messages?.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <Icon name="MessageSquare" size={48} className="text-text-secondary mb-4" />
              <h3 className="text-lg font-medium text-text-primary mb-2">
                Start Your Regulatory Compliance Query
              </h3>
              <p className="text-text-secondary max-w-md">
                Ask questions about RBI Digital Payment Security Controls, compliance requirements, 
                and regulatory guidelines for mobile applications.
              </p>
            </div>
          ) : (
            <div>
              {messages?.map(renderMessage)}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-4 border-t border-border">
          {error && (
            <div className="mb-3 p-3 bg-error/10 border border-error/20 rounded-lg">
              <div className="flex items-center space-x-2 text-error">
                <Icon name="AlertTriangle" size={16} />
                <span className="text-sm">{error}</span>
              </div>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="flex space-x-3">
            <div className="flex-1">
              <Input
                ref={inputRef}
                type="text"
                placeholder={
                  apiConfigured 
                    ? "Enter your regulatory compliance question..." :"Please configure RBI API in environment variables"
                }
                value={inputText}
                onChange={(e) => setInputText(e?.target?.value)}
                disabled={isLoading || !apiConfigured}
                className="w-full"
              />
            </div>
            
            <Button
              type="submit"
              disabled={!inputText?.trim() || isLoading || !apiConfigured}
              iconName={isLoading ? "Loader2" : "Send"}
              iconSize={16}
              className={isLoading ? "animate-spin" : ""}
            >
              {isLoading ? 'Processing...' : 'Send'}
            </Button>
          </form>
          
          <div className="text-xs text-text-secondary mt-2">
            Press Enter to send • This chat maintains conversation context for follow-up questions
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegulatoryComplianceChat;