import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChatInput = ({ 
  onSendMessage, 
  disabled = false, 
  isStreaming = false,
  currentMode = 'general-chat',
  placeholder = "Type your message..."
}) => {
  const [message, setMessage] = useState('');
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const textareaRef = useRef(null);

  const promptSuggestions = {
    'internal-circular': [
      "What are the latest updates to our loan approval process?",
      "Explain the new KYC requirements for corporate accounts",
      "What is our current policy on digital payment limits?",
      "How should we handle customer complaints about fees?"
    ],
    'rbi-circular': [
      "What are the recent RBI guidelines on digital lending?",
      "Explain the new Basel III capital requirements",
      "What are the current repo rate implications?",
      "How do the new NBFC regulations affect us?"
    ],
    'peer-comparison': [
      "How do our mobile banking features compare to HDFC?",
      "What are the competitive advantages of our savings account?",
      "Compare our loan interest rates with market leaders",
      "What unique features do we offer versus competitors?"
    ],
    'general-chat': [
      "What is the difference between NEFT and RTGS?",
      "How does compound interest work in savings accounts?",
      "What documents are needed for opening a current account?",
      "Explain the process of applying for a home loan"
    ]
  };

  const currentSuggestions = promptSuggestions[currentMode] || promptSuggestions['general-chat'];

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [message]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim() && !disabled && !isStreaming) {
      onSendMessage(message.trim());
      setMessage('');
      setShowSuggestions(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setMessage(suggestion);
    setShowSuggestions(false);
    textareaRef.current?.focus();
  };

  const handleVoiceToggle = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      setIsVoiceActive(!isVoiceActive);
      // Voice recognition implementation would go here
    } else {
      alert('Speech recognition is not supported in your browser');
    }
  };

  return (
    <div className="border-t border-subtle bg-surface">
      {/* Prompt Suggestions */}
      <AnimatePresence>
        {showSuggestions && currentSuggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="p-4 border-b border-subtle"
          >
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-medium text-text-primary">
                Suggested prompts for {currentMode.replace('-', ' ')}
              </h4>
              <Button
                variant="ghost"
                size="xs"
                onClick={() => setShowSuggestions(false)}
                iconName="X"
                iconSize={14}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {currentSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="text-sm px-3 py-2 bg-muted hover:bg-muted/80 text-text-primary rounded-lg transition-banking focus-banking text-left"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input Area */}
      <div className="p-4">
        <form onSubmit={handleSubmit} className="flex items-end space-x-3">
          {/* Voice Input Button */}
          <Button
            type="button"
            variant={isVoiceActive ? "default" : "ghost"}
            size="icon"
            onClick={handleVoiceToggle}
            disabled={disabled}
            className={`flex-shrink-0 ${isVoiceActive ? 'animate-pulse' : ''}`}
          >
            <Icon 
              name={isVoiceActive ? "MicOff" : "Mic"} 
              size={20} 
            />
          </Button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={disabled ? "Please wait..." : placeholder}
              disabled={disabled || isStreaming}
              className="w-full min-h-12 max-h-32 px-4 py-3 pr-12 bg-input border border-subtle rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-banking text-text-primary placeholder-text-secondary"
              rows={1}
            />
            
            {/* Character Count */}
            {message.length > 0 && (
              <div className="absolute bottom-2 right-2 text-xs text-text-secondary">
                {message.length}/2000
              </div>
            )}
          </div>

          {/* Send Button */}
          <Button
            type="submit"
            disabled={!message.trim() || disabled || isStreaming}
            loading={isStreaming}
            iconName="Send"
            iconSize={20}
            className="flex-shrink-0"
          >
            {isStreaming ? 'Sending...' : 'Send'}
          </Button>
        </form>

        {/* Status Indicators */}
        <div className="flex items-center justify-between mt-3 text-xs text-text-secondary">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-success rounded-full"></div>
              <span>Connected</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Zap" size={12} />
              <span>API Rate: 95/100</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <span>Press Enter to send, Shift+Enter for new line</span>
            <Button
              variant="ghost"
              size="xs"
              onClick={() => setShowSuggestions(!showSuggestions)}
              iconName="Lightbulb"
              iconSize={12}
              className="text-text-secondary"
              title="Toggle suggestions"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInput;