import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChatModeSelector = ({ currentMode, onModeChange, disabled = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const chatModes = [
    {
      id: 'internal-circular',
      label: 'Internal Circular Chat',
      icon: 'FileText',
      description: 'Access internal bank policies and circulars',
      color: 'text-primary',
      endpoint: '/api/internal-circular',
      systemPrompt: 'You are an expert in internal banking policies and procedures.',
      requiresAuth: true,
      auditLevel: 'high'
    },
    {
      id: 'rbi-circular',
      label: 'RBI Circular Chat',
      icon: 'Shield',
      description: 'RBI regulations and compliance guidance',
      color: 'text-error',
      endpoint: '/api/rbi-circular',
      systemPrompt: 'You are an expert in RBI regulations and banking compliance.',
      requiresAuth: true,
      auditLevel: 'critical'
    },
    {
      id: 'peer-comparison',
      label: 'Peer Feature Comparison',
      icon: 'TrendingUp',
      description: 'Compare features with competitor banks',
      color: 'text-accent',
      endpoint: '/api/peer-comparison',
      systemPrompt: 'You are an expert in competitive banking analysis.',
      requiresAuth: true,
      auditLevel: 'medium'
    },
    {
      id: 'general-chat',
      label: 'General Chat',
      icon: 'MessageCircle',
      description: 'General banking knowledge and assistance',
      color: 'text-text-secondary',
      endpoint: '/api/general-chat',
      systemPrompt: 'You are a helpful banking assistant.',
      requiresAuth: false,
      auditLevel: 'low'
    }
  ];

  const currentModeData = chatModes.find(mode => mode.id === currentMode) || chatModes[0];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleModeSelect = (mode) => {
    onModeChange(mode);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        variant="outline"
        onClick={() => setIsOpen(!isOpen)}
        disabled={disabled}
        iconName="ChevronDown"
        iconPosition="right"
        iconSize={16}
        className="min-w-64 justify-between"
      >
        <div className="flex items-center">
          <Icon 
            name={currentModeData.icon} 
            size={16} 
            className={`mr-2 ${currentModeData.color}`}
          />
          <span className="font-medium">{currentModeData.label}</span>
        </div>
      </Button>

      {isOpen && (
        <>
          {/* Backdrop */}
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          
          {/* Dropdown Menu */}
          <div className="absolute top-full left-0 mt-2 w-80 bg-popover border border-subtle rounded-lg elevation-2 z-50 animate-fade-in">
            <div className="py-2">
              {chatModes.map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => handleModeSelect(mode)}
                  className={`w-full flex items-start p-4 text-left hover:bg-muted transition-banking focus-banking ${
                    currentMode === mode.id ? 'bg-accent/10 border-l-2 border-accent' : ''
                  }`}
                >
                  <Icon 
                    name={mode.icon} 
                    size={20} 
                    className={`mr-3 mt-0.5 ${mode.color}`}
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-sm font-semibold text-text-primary">
                        {mode.label}
                      </h4>
                      <div className="flex items-center space-x-1">
                        {mode.requiresAuth && (
                          <Icon name="Lock" size={12} className="text-text-secondary" />
                        )}
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          mode.auditLevel === 'critical' ? 'bg-error/10 text-error' :
                          mode.auditLevel === 'high' ? 'bg-warning/10 text-warning' :
                          mode.auditLevel === 'medium'? 'bg-accent/10 text-accent' : 'bg-muted text-text-secondary'
                        }`}>
                          {mode.auditLevel}
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-text-secondary leading-relaxed">
                      {mode.description}
                    </p>
                  </div>
                </button>
              ))}
            </div>
            
            <div className="border-t border-subtle p-3">
              <div className="flex items-center text-xs text-text-secondary">
                <Icon name="Info" size={12} className="mr-1" />
                <span>Mode changes apply to new conversations</span>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ChatModeSelector;