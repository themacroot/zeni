import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ChatSidebar = ({ 
  currentSessionId, 
  onSessionSelect, 
  onNewChat,
  isCollapsed = false,
  onToggleCollapse 
}) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [sessions, setSessions] = useState([]);
  const [filteredSessions, setFilteredSessions] = useState([]);

  // Mock chat sessions data
  useEffect(() => {
    const mockSessions = [
      {
        id: 1,
        title: 'RBI Circular - Digital Lending Guidelines',
        mode: 'rbi-circular',
        timestamp: '2025-07-28T09:30:00',
        messageCount: 24,
        lastMessage: 'What are the key compliance requirements for digital lending platforms?',
        isActive: true,
        tags: ['compliance', 'digital-lending', 'rbi']
      },
      {
        id: 2,
        title: 'Internal Policy - KYC Updates',
        mode: 'internal-circular',
        timestamp: '2025-07-28T08:45:00',
        messageCount: 18,
        lastMessage: 'Please explain the new KYC documentation requirements for corporate accounts.',
        isActive: false,
        tags: ['kyc', 'corporate', 'policy']
      },
      {
        id: 3,
        title: 'Peer Analysis - Mobile Banking Features',
        mode: 'peer-comparison',
        timestamp: '2025-07-27T16:20:00',
        messageCount: 31,
        lastMessage: 'How do our mobile banking features compare with HDFC and ICICI?',
        isActive: false,
        tags: ['mobile-banking', 'competition', 'features']
      },
      {
        id: 4,
        title: 'General Banking - Loan Processing',
        mode: 'general-chat',
        timestamp: '2025-07-27T14:15:00',
        messageCount: 12,
        lastMessage: 'What documents are required for home loan application?',
        isActive: false,
        tags: ['loans', 'documentation', 'process']
      },
      {
        id: 5,
        title: 'RBI Guidelines - Basel III Implementation',
        mode: 'rbi-circular',
        timestamp: '2025-07-26T11:30:00',
        messageCount: 45,
        lastMessage: 'Explain the capital adequacy requirements under Basel III.',
        isActive: false,
        tags: ['basel-iii', 'capital', 'compliance']
      },
      {
        id: 6,
        title: 'Internal Circular - Branch Operations',
        mode: 'internal-circular',
        timestamp: '2025-07-25T15:45:00',
        messageCount: 22,
        lastMessage: 'What are the new operating hours for weekend banking?',
        isActive: false,
        tags: ['operations', 'branch', 'hours']
      }
    ];
    
    setSessions(mockSessions);
    setFilteredSessions(mockSessions);
  }, []);

  // Filter sessions based on search query
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredSessions(sessions);
    } else {
      const filtered = sessions.filter(session =>
        session.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        session.lastMessage.toLowerCase().includes(searchQuery.toLowerCase()) ||
        session.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
      setFilteredSessions(filtered);
    }
  }, [searchQuery, sessions]);

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 48) return 'Yesterday';
    return date.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
  };

  const getModeIcon = (mode) => {
    const modeIcons = {
      'rbi-circular': 'Shield',
      'internal-circular': 'FileText',
      'peer-comparison': 'TrendingUp',
      'general-chat': 'MessageCircle'
    };
    return modeIcons[mode] || 'MessageCircle';
  };

  const getModeColor = (mode) => {
    const modeColors = {
      'rbi-circular': 'text-error',
      'internal-circular': 'text-primary',
      'peer-comparison': 'text-accent',
      'general-chat': 'text-text-secondary'
    };
    return modeColors[mode] || 'text-text-secondary';
  };

  const handleSessionClick = (session) => {
    onSessionSelect(session);
  };

  const handleNewChat = () => {
    onNewChat();
  };

  const handleSessionManagement = () => {
    navigate('/chat-session-management');
  };

  return (
    <div className={`fixed left-0 top-16 h-[calc(100vh-4rem)] bg-surface border-r border-subtle z-90 transition-all duration-300 ${
      isCollapsed ? 'w-16' : 'w-80'
    }`}>
      <div className="flex flex-col h-full">
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-subtle">
          {!isCollapsed && (
            <h2 className="text-lg font-semibold text-text-primary">
              Chat History
            </h2>
          )}
          <div className="flex items-center space-x-2">
            {!isCollapsed && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleNewChat}
                iconName="Plus"
                iconSize={16}
                className="text-text-secondary"
              >
                New Chat
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleCollapse}
              className="text-text-secondary"
            >
              <Icon 
                name={isCollapsed ? "ChevronRight" : "ChevronLeft"} 
                size={16} 
              />
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        {!isCollapsed && (
          <div className="p-4 border-b border-subtle">
            <Input
              type="search"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
            />
          </div>
        )}

        {/* Session List */}
        <div className="flex-1 overflow-y-auto">
          <AnimatePresence>
            {filteredSessions.map((session) => (
              <motion.button
                key={session.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onClick={() => handleSessionClick(session)}
                className={`w-full flex items-start p-4 text-left hover:bg-muted transition-banking focus-banking border-b border-subtle/50 ${
                  currentSessionId === session.id ? 'bg-accent/10 border-l-2 border-accent' : ''
                }`}
                title={isCollapsed ? session.title : ''}
              >
                <div className={`flex-shrink-0 ${isCollapsed ? '' : 'mr-3'}`}>
                  <Icon 
                    name={getModeIcon(session.mode)} 
                    size={16} 
                    className={getModeColor(session.mode)}
                  />
                </div>
                
                {!isCollapsed && (
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-sm font-medium text-text-primary truncate">
                        {session.title}
                      </h4>
                      {session.isActive && (
                        <div className="w-2 h-2 bg-success rounded-full flex-shrink-0 ml-2"></div>
                      )}
                    </div>
                    
                    <p className="text-xs text-text-secondary line-clamp-2 mb-2">
                      {session.lastMessage}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs text-text-secondary">
                      <span>{session.messageCount} messages</span>
                      <span>{formatTimestamp(session.timestamp)}</span>
                    </div>
                  </div>
                )}
              </motion.button>
            ))}
          </AnimatePresence>
          
          {filteredSessions.length === 0 && searchQuery && (
            <div className="p-4 text-center">
              <Icon name="Search" size={24} className="text-text-secondary mx-auto mb-2" />
              <p className="text-sm text-text-secondary">
                No conversations found for "{searchQuery}"
              </p>
            </div>
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-subtle">
          {!isCollapsed ? (
            <div className="space-y-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSessionManagement}
                iconName="Settings"
                iconPosition="left"
                iconSize={16}
                className="w-full justify-start text-text-secondary"
              >
                Manage Sessions
              </Button>
              <div className="text-xs text-text-secondary">
                <div className="flex items-center justify-between">
                  <span>Storage used:</span>
                  <span>2.4 MB / 10 MB</span>
                </div>
                <div className="w-full bg-muted rounded-full h-1 mt-1">
                  <div className="bg-accent h-1 rounded-full" style={{ width: '24%' }}></div>
                </div>
              </div>
            </div>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSessionManagement}
              title="Manage Sessions"
              className="w-full text-text-secondary"
            >
              <Icon name="Settings" size={16} />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatSidebar;