import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const SessionFilters = ({ onFiltersChange, totalSessions, filteredCount }) => {
  const [filters, setFilters] = useState({
    searchQuery: '',
    selectedModes: [],
    dateRange: 'all',
    customDateStart: '',
    customDateEnd: '',
    department: 'all',
    participant: 'all',
    messageCountRange: 'all',
    complianceFlags: []
  });

  const [savedFilters, setSavedFilters] = useState([
    {
      id: 1,
      name: 'High Priority Compliance',
      filters: {
        selectedModes: ['regulatory'],
        complianceFlags: ['high-priority'],
        dateRange: 'last-7-days'
      }
    },
    {
      id: 2,
      name: 'Recent Policy Reviews',
      filters: {
        selectedModes: ['policy'],
        dateRange: 'last-30-days',
        messageCountRange: '10-plus'
      }
    }
  ]);

  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const chatModeOptions = [
    { value: 'regulatory', label: 'Regulatory Compliance' },
    { value: 'policy', label: 'Policy Analysis' },
    { value: 'competitive', label: 'Competitive Intelligence' },
    { value: 'general', label: 'General Banking' }
  ];

  const dateRangeOptions = [
    { value: 'all', label: 'All Time' },
    { value: 'today', label: 'Today' },
    { value: 'last-7-days', label: 'Last 7 Days' },
    { value: 'last-30-days', label: 'Last 30 Days' },
    { value: 'last-90-days', label: 'Last 90 Days' },
    { value: 'custom', label: 'Custom Range' }
  ];

  const departmentOptions = [
    { value: 'all', label: 'All Departments' },
    { value: 'compliance', label: 'Compliance' },
    { value: 'risk-management', label: 'Risk Management' },
    { value: 'operations', label: 'Operations' },
    { value: 'branch-banking', label: 'Branch Banking' },
    { value: 'corporate-banking', label: 'Corporate Banking' }
  ];

  const participantOptions = [
    { value: 'all', label: 'All Participants' },
    { value: 'sarah-johnson', label: 'Sarah Johnson' },
    { value: 'mike-chen', label: 'Mike Chen' },
    { value: 'priya-sharma', label: 'Priya Sharma' },
    { value: 'raj-patel', label: 'Raj Patel' }
  ];

  const messageCountOptions = [
    { value: 'all', label: 'Any Count' },
    { value: '1-10', label: '1-10 Messages' },
    { value: '11-25', label: '11-25 Messages' },
    { value: '26-50', label: '26-50 Messages' },
    { value: '50-plus', label: '50+ Messages' }
  ];

  const complianceFlagOptions = [
    { value: 'high-priority', label: 'High Priority' },
    { value: 'confidential', label: 'Confidential' },
    { value: 'audit-required', label: 'Audit Required' },
    { value: 'regulatory-review', label: 'Regulatory Review' }
  ];

  useEffect(() => {
    onFiltersChange(filters);
  }, [filters, onFiltersChange]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleModeToggle = (modeValue) => {
    setFilters(prev => ({
      ...prev,
      selectedModes: prev.selectedModes.includes(modeValue)
        ? prev.selectedModes.filter(m => m !== modeValue)
        : [...prev.selectedModes, modeValue]
    }));
  };

  const handleComplianceFlagToggle = (flagValue) => {
    setFilters(prev => ({
      ...prev,
      complianceFlags: prev.complianceFlags.includes(flagValue)
        ? prev.complianceFlags.filter(f => f !== flagValue)
        : [...prev.complianceFlags, flagValue]
    }));
  };

  const applySavedFilter = (savedFilter) => {
    setFilters(prev => ({
      ...prev,
      ...savedFilter.filters
    }));
  };

  const clearAllFilters = () => {
    setFilters({
      searchQuery: '',
      selectedModes: [],
      dateRange: 'all',
      customDateStart: '',
      customDateEnd: '',
      department: 'all',
      participant: 'all',
      messageCountRange: 'all',
      complianceFlags: []
    });
  };

  const saveCurrentFilter = () => {
    const filterName = prompt('Enter filter name:');
    if (filterName) {
      const newFilter = {
        id: Date.now(),
        name: filterName,
        filters: { ...filters }
      };
      setSavedFilters(prev => [...prev, newFilter]);
    }
  };

  return (
    <div className="bg-surface border-r border-subtle h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-subtle">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-text-primary">
            Session Filters
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            iconName={showAdvancedFilters ? "ChevronUp" : "ChevronDown"}
            iconSize={16}
          >
            Advanced
          </Button>
        </div>

        {/* Results Summary */}
        <div className="text-sm text-text-secondary mb-4">
          Showing {filteredCount.toLocaleString()} of {totalSessions.toLocaleString()} sessions
        </div>

        {/* Global Search */}
        <Input
          type="search"
          placeholder="Search sessions..."
          value={filters.searchQuery}
          onChange={(e) => handleFilterChange('searchQuery', e.target.value)}
          className="mb-4"
        />
      </div>

      {/* Filter Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Saved Filters */}
        <div>
          <h3 className="text-sm font-medium text-text-primary mb-3">
            Saved Filters
          </h3>
          <div className="space-y-2">
            {savedFilters.map((savedFilter) => (
              <button
                key={savedFilter.id}
                onClick={() => applySavedFilter(savedFilter)}
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-banking focus-banking text-left"
              >
                <span className="text-sm text-text-primary">
                  {savedFilter.name}
                </span>
                <Icon name="ChevronRight" size={14} className="text-text-secondary" />
              </button>
            ))}
            <Button
              variant="ghost"
              size="sm"
              onClick={saveCurrentFilter}
              iconName="Plus"
              iconSize={14}
              className="w-full justify-start text-xs"
            >
              Save Current Filter
            </Button>
          </div>
        </div>

        {/* Chat Modes */}
        <div>
          <h3 className="text-sm font-medium text-text-primary mb-3">
            Chat Modes
          </h3>
          <div className="space-y-2">
            {chatModeOptions.map((mode) => (
              <button
                key={mode.value}
                onClick={() => handleModeToggle(mode.value)}
                className={`w-full flex items-center p-2 rounded-lg transition-banking focus-banking ${
                  filters.selectedModes.includes(mode.value)
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-muted text-text-primary'
                }`}
              >
                <Icon 
                  name={filters.selectedModes.includes(mode.value) ? "CheckSquare" : "Square"} 
                  size={16} 
                  className="mr-2" 
                />
                <span className="text-sm">{mode.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Date Range */}
        <div>
          <h3 className="text-sm font-medium text-text-primary mb-3">
            Date Range
          </h3>
          <Select
            options={dateRangeOptions}
            value={filters.dateRange}
            onChange={(value) => handleFilterChange('dateRange', value)}
            className="mb-3"
          />
          {filters.dateRange === 'custom' && (
            <div className="space-y-2">
              <Input
                type="date"
                label="Start Date"
                value={filters.customDateStart}
                onChange={(e) => handleFilterChange('customDateStart', e.target.value)}
              />
              <Input
                type="date"
                label="End Date"
                value={filters.customDateEnd}
                onChange={(e) => handleFilterChange('customDateEnd', e.target.value)}
              />
            </div>
          )}
        </div>

        {/* Advanced Filters */}
        {showAdvancedFilters && (
          <>
            {/* Department */}
            <div>
              <h3 className="text-sm font-medium text-text-primary mb-3">
                Department
              </h3>
              <Select
                options={departmentOptions}
                value={filters.department}
                onChange={(value) => handleFilterChange('department', value)}
              />
            </div>

            {/* Participant */}
            <div>
              <h3 className="text-sm font-medium text-text-primary mb-3">
                Participant
              </h3>
              <Select
                options={participantOptions}
                value={filters.participant}
                onChange={(value) => handleFilterChange('participant', value)}
              />
            </div>

            {/* Message Count */}
            <div>
              <h3 className="text-sm font-medium text-text-primary mb-3">
                Message Count
              </h3>
              <Select
                options={messageCountOptions}
                value={filters.messageCountRange}
                onChange={(value) => handleFilterChange('messageCountRange', value)}
              />
            </div>

            {/* Compliance Flags */}
            <div>
              <h3 className="text-sm font-medium text-text-primary mb-3">
                Compliance Flags
              </h3>
              <div className="space-y-2">
                {complianceFlagOptions.map((flag) => (
                  <button
                    key={flag.value}
                    onClick={() => handleComplianceFlagToggle(flag.value)}
                    className={`w-full flex items-center p-2 rounded-lg transition-banking focus-banking ${
                      filters.complianceFlags.includes(flag.value)
                        ? 'bg-warning text-warning-foreground'
                        : 'hover:bg-muted text-text-primary'
                    }`}
                  >
                    <Icon 
                      name={filters.complianceFlags.includes(flag.value) ? "CheckSquare" : "Square"} 
                      size={16} 
                      className="mr-2" 
                    />
                    <span className="text-sm">{flag.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-subtle">
        <div className="space-y-2">
          <Button
            variant="outline"
            size="sm"
            onClick={clearAllFilters}
            iconName="X"
            iconSize={14}
            className="w-full"
          >
            Clear All Filters
          </Button>
          <div className="text-xs text-text-secondary text-center">
            Use Ctrl+F for quick search
          </div>
        </div>
      </div>
    </div>
  );
};

export default SessionFilters;