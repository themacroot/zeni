import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import SessionFilters from './components/SessionFilters';
import SessionTable from './components/SessionTable';
import SessionPreview from './components/SessionPreview';
import BulkOperationsToolbar from './components/BulkOperationsToolbar';
import SystemStatusPanel from './components/SystemStatusPanel';
import RegulatoryComplianceChat from './components/RegulatoryComplianceChat';

import Button from '../../components/ui/Button';

const ChatSessionManagement = () => {
  const navigate = useNavigate();
  const [currentUser] = useState({
    id: 1,
    name: 'Sarah Johnson',
    role: 'admin', // 'compliance', 'admin', 'user'
    department: 'compliance'
  });

  // Mock sessions data
  const [allSessions] = useState([
    {
      id: 1,
      title: 'RBI Digital Lending Guidelines Q3 2025',
      mode: 'regulatory',
      timestamp: '2025-07-28T09:30:00',
      messageCount: 24,
      participants: ['Sarah Johnson'],
      complianceFlags: ['high-priority'],
      department: 'compliance',
      lastActivity: '2025-07-28T09:30:00'
    },
    {
      id: 2,
      title: 'Internal Policy Clarification - KYC Updates',
      mode: 'policy',
      timestamp: '2025-07-28T08:45:00',
      messageCount: 18,
      participants: ['Sarah Johnson', 'Mike Chen'],
      complianceFlags: [],
      department: 'compliance',
      lastActivity: '2025-07-28T08:45:00'
    },
    {
      id: 3,
      title: 'Competitive Analysis - HDFC Mobile Features',
      mode: 'competitive',
      timestamp: '2025-07-27T16:20:00',
      messageCount: 31,
      participants: ['Sarah Johnson'],
      complianceFlags: ['confidential'],
      department: 'competitive-intelligence',
      lastActivity: '2025-07-27T16:20:00'
    },
    {
      id: 4,
      title: 'General Banking Query - Account Types',
      mode: 'general',
      timestamp: '2025-07-27T14:15:00',
      messageCount: 12,
      participants: ['Sarah Johnson'],
      complianceFlags: [],
      department: 'operations',
      lastActivity: '2025-07-27T14:15:00'
    },
    {
      id: 5,
      title: 'Basel III Implementation Guidelines',
      mode: 'regulatory',
      timestamp: '2025-07-26T11:30:00',
      messageCount: 45,
      participants: ['Sarah Johnson', 'Priya Sharma', 'Raj Patel'],
      complianceFlags: ['high-priority', 'audit-required'],
      department: 'risk-management',
      lastActivity: '2025-07-26T11:30:00'
    },
    {
      id: 6,
      title: 'Credit Card Policy Updates 2025',
      mode: 'policy',
      timestamp: '2025-07-26T09:15:00',
      messageCount: 22,
      participants: ['Mike Chen', 'Sarah Johnson'],
      complianceFlags: ['regulatory-review'],
      department: 'product-management',
      lastActivity: '2025-07-26T09:15:00'
    },
    {
      id: 7,
      title: 'SBI vs ICICI Feature Comparison',
      mode: 'competitive',
      timestamp: '2025-07-25T15:45:00',
      messageCount: 38,
      participants: ['Sarah Johnson'],
      complianceFlags: ['confidential'],
      department: 'competitive-intelligence',
      lastActivity: '2025-07-25T15:45:00'
    },
    {
      id: 8,
      title: 'Customer Onboarding Process Query',
      mode: 'general',
      timestamp: '2025-07-25T13:20:00',
      messageCount: 15,
      participants: ['Sarah Johnson', 'Branch Manager Delhi'],
      complianceFlags: [],
      department: 'branch-banking',
      lastActivity: '2025-07-25T13:20:00'
    },
    {
      id: 9,
      title: 'PMLA Compliance Requirements 2025',
      mode: 'regulatory',
      timestamp: '2025-07-24T16:00:00',
      messageCount: 52,
      participants: ['Sarah Johnson', 'Compliance Team'],
      complianceFlags: ['high-priority', 'audit-required'],
      department: 'compliance',
      lastActivity: '2025-07-24T16:00:00'
    },
    {
      id: 10,
      title: 'Loan Processing Policy Review',
      mode: 'policy',
      timestamp: '2025-07-24T10:30:00',
      messageCount: 29,
      participants: ['Sarah Johnson', 'Loan Officers'],
      complianceFlags: [],
      department: 'lending',
      lastActivity: '2025-07-24T10:30:00'
    }
  ]);

  const [filteredSessions, setFilteredSessions] = useState(allSessions);
  const [selectedSessions, setSelectedSessions] = useState([]);
  const [previewSession, setPreviewSession] = useState(null);
  const [showSystemStatus, setShowSystemStatus] = useState(currentUser?.role === 'admin');
  const [showRegulatoryChat, setShowRegulatoryChat] = useState(false);
  const [selectedRegulatorySession, setSelectedRegulatorySession] = useState(null);

  // Filter sessions based on applied filters
  const handleFiltersChange = useCallback((filters) => {
    let filtered = [...allSessions];

    // Search query filter
    if (filters?.searchQuery) {
      const query = filters?.searchQuery?.toLowerCase();
      filtered = filtered?.filter(session =>
        session?.title?.toLowerCase()?.includes(query) ||
        session?.participants?.some(p => p?.toLowerCase()?.includes(query))
      );
    }

    // Mode filter
    if (filters?.selectedModes?.length > 0) {
      filtered = filtered?.filter(session =>
        filters?.selectedModes?.includes(session?.mode)
      );
    }

    // Date range filter
    if (filters?.dateRange !== 'all') {
      const now = new Date();
      const filterDate = new Date();

      switch (filters?.dateRange) {
        case 'today':
          filterDate?.setHours(0, 0, 0, 0);
          break;
        case 'last-7-days':
          filterDate?.setDate(now?.getDate() - 7);
          break;
        case 'last-30-days':
          filterDate?.setDate(now?.getDate() - 30);
          break;
        case 'last-90-days':
          filterDate?.setDate(now?.getDate() - 90);
          break;
        case 'custom':
          if (filters?.customDateStart && filters?.customDateEnd) {
            const startDate = new Date(filters.customDateStart);
            const endDate = new Date(filters.customDateEnd);
            filtered = filtered?.filter(session => {
              const sessionDate = new Date(session.timestamp);
              return sessionDate >= startDate && sessionDate <= endDate;
            });
          }
          break;
        default:
          break;
      }

      if (filters?.dateRange !== 'custom') {
        filtered = filtered?.filter(session =>
          new Date(session.timestamp) >= filterDate
        );
      }
    }

    // Department filter
    if (filters?.department !== 'all') {
      filtered = filtered?.filter(session =>
        session?.department === filters?.department
      );
    }

    // Participant filter
    if (filters?.participant !== 'all') {
      filtered = filtered?.filter(session =>
        session?.participants?.some(p => 
          p?.toLowerCase()?.replace(' ', '-') === filters?.participant
        )
      );
    }

    // Message count filter
    if (filters?.messageCountRange !== 'all') {
      filtered = filtered?.filter(session => {
        const count = session?.messageCount;
        switch (filters?.messageCountRange) {
          case '1-10':
            return count >= 1 && count <= 10;
          case '11-25':
            return count >= 11 && count <= 25;
          case '26-50':
            return count >= 26 && count <= 50;
          case '50-plus':
            return count > 50;
          default:
            return true;
        }
      });
    }

    // Compliance flags filter
    if (filters?.complianceFlags?.length > 0) {
      filtered = filtered?.filter(session =>
        filters?.complianceFlags?.some(flag =>
          session?.complianceFlags?.includes(flag)
        )
      );
    }

    setFilteredSessions(filtered);
  }, [allSessions]);

  const handleSessionSelect = (sessionIds) => {
    setSelectedSessions(sessionIds);
  };

  const handleSessionPreview = (session) => {
    setPreviewSession(session);
  };

  const handleBulkAction = (action, options = {}) => {
    console.log('Bulk action:', action, 'Options:', options, 'Sessions:', selectedSessions);
    
    switch (action) {
      case 'export':
        // Mock export functionality
        alert(`Exporting ${selectedSessions?.length} sessions in ${options?.format || 'JSON'} format`);
        break;
      case 'delete':
        // Mock delete functionality
        if (confirm(`Are you sure you want to delete ${selectedSessions?.length} sessions?`)) {
          alert(`Deleted ${selectedSessions?.length} sessions`);
          setSelectedSessions([]);
        }
        break;
      case 'categorize':
        alert(`Categorized ${selectedSessions?.length} sessions as ${options?.category}`);
        break;
      case 'backup':
        alert(`Created backup for ${selectedSessions?.length} sessions`);
        break;
      case 'migrate':
        alert(`Migrated ${selectedSessions?.length} sessions to long-term storage`);
        break;
      default:
        console.log('Unknown bulk action:', action);
    }
  };

  const handleExport = (sessionId, format) => {
    console.log('Exporting session:', sessionId, 'Format:', format);
    alert(`Exporting session in ${format?.toUpperCase()} format`);
  };

  const clearSelection = () => {
    setSelectedSessions([]);
  };

  const handleStartRegulatoryChat = (session = null) => {
    setSelectedRegulatorySession(session);
    setShowRegulatoryChat(true);
  };

  const handleCloseRegulatoryChat = () => {
    setShowRegulatoryChat(false);
    setSelectedRegulatorySession(null);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e?.ctrlKey || e?.metaKey) {
        switch (e?.key) {
          case 'a':
            e?.preventDefault();
            setSelectedSessions(filteredSessions?.map(s => s?.id));
            break;
          case 'e':
            e?.preventDefault();
            if (selectedSessions?.length > 0) {
              handleBulkAction('export', { format: 'json' });
            }
            break;
          case 'r':
            e?.preventDefault();
            handleStartRegulatoryChat();
            break;
          case 'Escape':
            e?.preventDefault();
            clearSelection();
            setPreviewSession(null);
            if (showRegulatoryChat) {
              handleCloseRegulatoryChat();
            }
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedSessions, filteredSessions, showRegulatoryChat]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      <div className="lg:ml-80 pt-16">
        <div className="h-[calc(100vh-4rem)] flex">
          {/* Left Panel - Filters (20%) */}
          <div className="w-1/5 min-w-64">
            <SessionFilters
              onFiltersChange={handleFiltersChange}
              totalSessions={allSessions?.length}
              filteredCount={filteredSessions?.length}
            />
          </div>

          {/* Center Panel - Session Table (60%) */}
          <div className="flex-1 flex flex-col">
            {/* Page Header */}
            <div className="p-6 border-b border-subtle bg-surface">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-text-primary mb-2">
                    Chat Session Management
                  </h1>
                  <p className="text-text-secondary">
                    Comprehensive administration interface for banking conversation history
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <Button
                    variant="outline"
                    onClick={() => navigate('/chat-interface-dashboard')}
                    iconName="MessageSquare"
                    iconSize={16}
                  >
                    New Chat
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => handleStartRegulatoryChat()}
                    iconName="Shield"
                    iconSize={16}
                    className="text-error hover:text-error"
                  >
                    Regulatory Compliance
                  </Button>
                  {currentUser?.role === 'admin' && (
                    <Button
                      variant="ghost"
                      onClick={() => setShowSystemStatus(!showSystemStatus)}
                      iconName={showSystemStatus ? "EyeOff" : "Eye"}
                      iconSize={16}
                    >
                      {showSystemStatus ? 'Hide' : 'Show'} System Status
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {/* Bulk Operations Toolbar */}
            <BulkOperationsToolbar
              selectedCount={selectedSessions?.length}
              onBulkAction={handleBulkAction}
              onClearSelection={clearSelection}
              totalSessions={filteredSessions?.length}
              currentUser={currentUser}
            />

            {/* Session Table */}
            <div className="flex-1">
              <SessionTable
                sessions={filteredSessions}
                selectedSessions={selectedSessions}
                onSessionSelect={handleSessionSelect}
                onSessionPreview={handleSessionPreview}
                onBulkAction={handleBulkAction}
                onStartRegulatoryChat={handleStartRegulatoryChat}
                currentUser={currentUser}
              />
            </div>
          </div>

          {/* Right Panel - Preview/System Status (20%) */}
          <div className="w-1/5 min-w-80">
            {showSystemStatus && currentUser?.role === 'admin' ? (
              <SystemStatusPanel currentUser={currentUser} />
            ) : (
              <SessionPreview
                session={previewSession}
                onExport={handleExport}
                onClose={() => setPreviewSession(null)}
              />
            )}
          </div>
        </div>
      </div>
      {/* Regulatory Compliance Chat Modal */}
      <RegulatoryComplianceChat
        isVisible={showRegulatoryChat}
        onClose={handleCloseRegulatoryChat}
        sessionData={selectedRegulatorySession}
      />
    </div>
  );
};

export default ChatSessionManagement;