import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import ChatModeSelector from './ChatModeSelector';

const ChatToolbar = ({ 
  currentMode, 
  onModeChange, 
  currentSession,
  onExportSession,
  onSessionSettings,
  disabled = false 
}) => {
  const navigate = useNavigate();
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async (format) => {
    setIsExporting(true);
    try {
      // Mock export functionality
      await new Promise(resolve => setTimeout(resolve, 1500));
      onExportSession?.(currentSession, format);
    } finally {
      setIsExporting(false);
    }
  };

  const handleSessionManagement = () => {
    navigate('/chat-session-management');
  };

  const getConnectionStatus = () => {
    // Mock connection status
    return {
      status: 'connected',
      latency: '45ms',
      apiHealth: 'healthy'
    };
  };

  const connectionStatus = getConnectionStatus();

  return (
    <div className="flex items-center justify-between p-4 bg-surface border-b border-subtle">
      {/* Left Section - Mode Selector */}
      <div className="flex items-center space-x-4">
        <ChatModeSelector
          currentMode={currentMode}
          onModeChange={onModeChange}
          disabled={disabled}
        />
        
        {/* Connection Status */}
        <div className="flex items-center space-x-2 text-sm text-text-secondary">
          <div className={`w-2 h-2 rounded-full ${
            connectionStatus.status === 'connected' ? 'bg-success' :
            connectionStatus.status === 'connecting'? 'bg-warning' : 'bg-error'
          }`}></div>
          <span className="hidden sm:inline">
            {connectionStatus.status === 'connected' ? 'Connected' : 'Disconnected'}
          </span>
          <span className="hidden md:inline text-xs">
            ({connectionStatus.latency})
          </span>
        </div>
      </div>

      {/* Center Section - Session Info */}
      <div className="flex items-center space-x-3">
        {currentSession && (
          <div className="text-center">
            <h3 className="text-sm font-medium text-text-primary truncate max-w-48">
              {currentSession.title}
            </h3>
            <div className="flex items-center justify-center space-x-2 text-xs text-text-secondary">
              <span>{currentSession.messageCount} messages</span>
              <span>•</span>
              <span>{new Date(currentSession.timestamp).toLocaleDateString('en-IN')}</span>
            </div>
          </div>
        )}
      </div>

      {/* Right Section - Actions */}
      <div className="flex items-center space-x-2">
        {/* Voice Input Toggle */}
        <Button
          variant="ghost"
          size="icon"
          disabled={disabled}
          title="Voice Input (Coming Soon)"
          className="text-text-secondary"
        >
          <Icon name="Mic" size={18} />
        </Button>

        {/* Export Options */}
        <div className="relative group">
          <Button
            variant="ghost"
            size="icon"
            disabled={disabled || !currentSession}
            title="Export Session"
            className="text-text-secondary"
          >
            <Icon name="Download" size={18} />
          </Button>
          
          {/* Export Dropdown */}
          <div className="absolute right-0 top-full mt-2 w-48 bg-popover border border-subtle rounded-lg elevation-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
            <div className="py-2">
              <button
                onClick={() => handleExport('pdf')}
                disabled={isExporting}
                className="w-full flex items-center px-4 py-2 text-sm text-text-primary hover:bg-muted transition-banking"
              >
                <Icon name="FileText" size={16} className="mr-3" />
                Export as PDF
              </button>
              <button
                onClick={() => handleExport('json')}
                disabled={isExporting}
                className="w-full flex items-center px-4 py-2 text-sm text-text-primary hover:bg-muted transition-banking"
              >
                <Icon name="Code" size={16} className="mr-3" />
                Export as JSON
              </button>
              <button
                onClick={() => handleExport('txt')}
                disabled={isExporting}
                className="w-full flex items-center px-4 py-2 text-sm text-text-primary hover:bg-muted transition-banking"
              >
                <Icon name="FileText" size={16} className="mr-3" />
                Export as Text
              </button>
            </div>
          </div>
        </div>

        {/* Session Settings */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onSessionSettings}
          disabled={disabled || !currentSession}
          title="Session Settings"
          className="text-text-secondary"
        >
          <Icon name="Settings" size={18} />
        </Button>

        {/* Session Management */}
        <Button
          variant="ghost"
          size="icon"
          onClick={handleSessionManagement}
          title="Manage All Sessions"
          className="text-text-secondary"
        >
          <Icon name="FolderOpen" size={18} />
        </Button>

        {/* API Status */}
        <div className="hidden lg:flex items-center space-x-2 px-3 py-1 bg-muted rounded-lg">
          <Icon 
            name="Zap" 
            size={14} 
            className={connectionStatus.apiHealth === 'healthy' ? 'text-success' : 'text-warning'}
          />
          <span className="text-xs text-text-secondary">
            API: {connectionStatus.apiHealth}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ChatToolbar;