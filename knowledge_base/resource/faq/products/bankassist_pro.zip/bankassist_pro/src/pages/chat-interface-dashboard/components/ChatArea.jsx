import React, { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ChatMessage from './ChatMessage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ChatArea = ({ 
  messages = [], 
  isStreaming = false, 
  onMessageFeedback,
  onMessageCopy,
  onMessageShare,
  currentSession,
  autoScroll = true 
}) => {
  const messagesEndRef = useRef(null);
  const chatContainerRef = useRef(null);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [isUserScrolling, setIsUserScrolling] = useState(false);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (autoScroll && !isUserScrolling) {
      scrollToBottom();
    }
  }, [messages, isStreaming, autoScroll, isUserScrolling]);

  // Handle scroll events to detect user scrolling
  useEffect(() => {
    const container = chatContainerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isAtBottom = scrollHeight - scrollTop - clientHeight < 100;
      
      setShowScrollButton(!isAtBottom);
      
      // If user scrolls up, disable auto-scroll temporarily
      if (!isAtBottom) {
        setIsUserScrolling(true);
      } else {
        setIsUserScrolling(false);
      }
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ 
      behavior: 'smooth',
      block: 'end'
    });
  };

  const handleScrollToBottom = () => {
    setIsUserScrolling(false);
    scrollToBottom();
  };

  const handleMessageFeedback = (messageId, feedback) => {
    onMessageFeedback?.(messageId, feedback);
  };

  const handleMessageCopy = (messageId) => {
    onMessageCopy?.(messageId);
  };

  const handleMessageShare = (message) => {
    onMessageShare?.(message);
  };

  // Welcome message for new sessions
  const WelcomeMessage = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-12 text-center"
    >
      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
        <Icon name="Building2" size={32} className="text-primary" />
      </div>
      <h2 className="text-2xl font-semibold text-text-primary mb-2">
        Welcome to BankAssist Pro
      </h2>
      <p className="text-text-secondary max-w-md mb-6">
        Your intelligent banking assistant is ready to help with regulatory compliance, 
        internal policies, competitive analysis, and general banking queries.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl">
        <div className="p-4 bg-card border border-subtle rounded-lg">
          <Icon name="Shield" size={20} className="text-error mb-2" />
          <h3 className="font-medium text-text-primary mb-1">RBI Compliance</h3>
          <p className="text-sm text-text-secondary">
            Get instant access to RBI circulars and regulatory guidance
          </p>
        </div>
        <div className="p-4 bg-card border border-subtle rounded-lg">
          <Icon name="FileText" size={20} className="text-primary mb-2" />
          <h3 className="font-medium text-text-primary mb-1">Internal Policies</h3>
          <p className="text-sm text-text-secondary">
            Quick clarification on internal banking policies and procedures
          </p>
        </div>
        <div className="p-4 bg-card border border-subtle rounded-lg">
          <Icon name="TrendingUp" size={20} className="text-accent mb-2" />
          <h3 className="font-medium text-text-primary mb-1">Market Analysis</h3>
          <p className="text-sm text-text-secondary">
            Compare features and strategies with peer institutions
          </p>
        </div>
        <div className="p-4 bg-card border border-subtle rounded-lg">
          <Icon name="MessageCircle" size={20} className="text-text-secondary mb-2" />
          <h3 className="font-medium text-text-primary mb-1">General Banking</h3>
          <p className="text-sm text-text-secondary">
            Comprehensive banking knowledge and operational support
          </p>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="flex-1 flex flex-col relative bg-background">
      {/* Chat Messages Container */}
      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto px-6 py-4"
        style={{ scrollBehavior: 'smooth' }}
      >
        {messages.length === 0 ? (
          <WelcomeMessage />
        ) : (
          <div className="max-w-4xl mx-auto">
            <AnimatePresence mode="popLayout">
              {messages.map((message, index) => (
                <ChatMessage
                  key={message.id || index}
                  message={message}
                  isStreaming={isStreaming && index === messages.length - 1}
                  onFeedback={handleMessageFeedback}
                  onCopy={handleMessageCopy}
                  onShare={handleMessageShare}
                  showAvatar={true}
                />
              ))}
            </AnimatePresence>
            
            {/* Streaming Indicator */}
            {isStreaming && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center space-x-2 text-text-secondary text-sm mb-4"
              >
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span>BankAssist Pro is thinking...</span>
              </motion.div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Scroll to Bottom Button */}
      <AnimatePresence>
        {showScrollButton && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute bottom-4 right-6 z-10"
          >
            <Button
              variant="default"
              size="icon"
              onClick={handleScrollToBottom}
              className="rounded-full shadow-lg"
              title="Scroll to bottom"
            >
              <Icon name="ChevronDown" size={20} />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Session Info Bar */}
      {currentSession && messages.length > 0 && (
        <div className="px-6 py-2 bg-muted/50 border-t border-subtle">
          <div className="max-w-4xl mx-auto flex items-center justify-between text-xs text-text-secondary">
            <div className="flex items-center space-x-4">
              <span>Session: {currentSession.title}</span>
              <span>•</span>
              <span>{messages.length} messages</span>
              <span>•</span>
              <span>Started {new Date(currentSession.timestamp).toLocaleString('en-IN')}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={12} />
              <span>Last updated: {new Date().toLocaleTimeString('en-IN', { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatArea;