import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SystemStatusPanel = ({ currentUser }) => {
  const [systemStats, setSystemStats] = useState({
    totalSessions: 15847,
    totalStorage: 2.4, // GB
    backupStatus: 'completed',
    lastBackup: new Date('2025-07-28T06:00:00'),
    syncStatus: 'active',
    lastSync: new Date('2025-07-28T09:35:00'),
    activeUsers: 23,
    systemHealth: 'healthy'
  });

  const [replicationStatus, setReplicationStatus] = useState([
    {
      branch: 'Mumbai Central',
      status: 'synced',
      lastSync: new Date('2025-07-28T09:35:00'),
      sessionCount: 3247
    },
    {
      branch: 'Delhi North',
      status: 'syncing',
      lastSync: new Date('2025-07-28T09:30:00'),
      sessionCount: 2891
    },
    {
      branch: 'Bangalore Tech',
      status: 'synced',
      lastSync: new Date('2025-07-28T09:34:00'),
      sessionCount: 4123
    },
    {
      branch: 'Chennai Regional',
      status: 'error',
      lastSync: new Date('2025-07-28T08:45:00'),
      sessionCount: 2156
    }
  ]);

  const getStatusColor = (status) => {
    const colors = {
      'completed': 'text-success',
      'active': 'text-success',
      'synced': 'text-success',
      'syncing': 'text-warning',
      'error': 'text-error',
      'healthy': 'text-success'
    };
    return colors[status] || 'text-text-secondary';
  };

  const getStatusIcon = (status) => {
    const icons = {
      'completed': 'CheckCircle',
      'active': 'Activity',
      'synced': 'CheckCircle',
      'syncing': 'RefreshCw',
      'error': 'AlertCircle',
      'healthy': 'Heart'
    };
    return icons[status] || 'Circle';
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now - timestamp) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return timestamp.toLocaleDateString('en-IN');
  };

  const handleManualBackup = () => {
    // Mock backup initiation
    setSystemStats(prev => ({
      ...prev,
      backupStatus: 'running'
    }));
    
    setTimeout(() => {
      setSystemStats(prev => ({
        ...prev,
        backupStatus: 'completed',
        lastBackup: new Date()
      }));
    }, 3000);
  };

  const handleForceSync = (branchId) => {
    setReplicationStatus(prev => 
      prev.map(branch => 
        branch.branch === branchId 
          ? { ...branch, status: 'syncing' }
          : branch
      )
    );

    setTimeout(() => {
      setReplicationStatus(prev => 
        prev.map(branch => 
          branch.branch === branchId 
            ? { ...branch, status: 'synced', lastSync: new Date() }
            : branch
        )
      );
    }, 2000);
  };

  // Only show for admin users
  if (currentUser?.role !== 'admin') {
    return null;
  }

  return (
    <div className="bg-surface border-l border-subtle h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-subtle">
        <div className="flex items-center space-x-2 mb-2">
          <Icon name="Server" size={20} className="text-primary" />
          <h2 className="text-lg font-semibold text-text-primary">
            System Status
          </h2>
        </div>
        <p className="text-sm text-text-secondary">
          Real-time system health and replication status
        </p>
      </div>

      {/* System Overview */}
      <div className="p-4 border-b border-subtle">
        <h3 className="text-sm font-medium text-text-primary mb-3">
          System Overview
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-text-secondary">Total Sessions</span>
              <Icon name="MessageSquare" size={14} className="text-text-secondary" />
            </div>
            <span className="text-lg font-semibold text-text-primary">
              {systemStats.totalSessions.toLocaleString()}
            </span>
          </div>
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-text-secondary">Storage Used</span>
              <Icon name="HardDrive" size={14} className="text-text-secondary" />
            </div>
            <span className="text-lg font-semibold text-text-primary">
              {systemStats.totalStorage} GB
            </span>
          </div>
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-text-secondary">Active Users</span>
              <Icon name="Users" size={14} className="text-text-secondary" />
            </div>
            <span className="text-lg font-semibold text-text-primary">
              {systemStats.activeUsers}
            </span>
          </div>
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-text-secondary">System Health</span>
              <Icon 
                name={getStatusIcon(systemStats.systemHealth)} 
                size={14} 
                className={getStatusColor(systemStats.systemHealth)} 
              />
            </div>
            <span className="text-lg font-semibold text-text-primary capitalize">
              {systemStats.systemHealth}
            </span>
          </div>
        </div>
      </div>

      {/* Backup Status */}
      <div className="p-4 border-b border-subtle">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-text-primary">
            Backup Status
          </h3>
          <Button
            variant="outline"
            size="sm"
            onClick={handleManualBackup}
            disabled={systemStats.backupStatus === 'running'}
            iconName={systemStats.backupStatus === 'running' ? "RefreshCw" : "Archive"}
            iconSize={14}
            className={systemStats.backupStatus === 'running' ? 'animate-spin' : ''}
          >
            {systemStats.backupStatus === 'running' ? 'Running...' : 'Manual Backup'}
          </Button>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Last Backup:</span>
            <div className="flex items-center space-x-2">
              <Icon 
                name={getStatusIcon(systemStats.backupStatus)} 
                size={14} 
                className={getStatusColor(systemStats.backupStatus)} 
              />
              <span className="text-sm text-text-primary">
                {formatTimestamp(systemStats.lastBackup)}
              </span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Status:</span>
            <span className={`text-sm capitalize ${getStatusColor(systemStats.backupStatus)}`}>
              {systemStats.backupStatus}
            </span>
          </div>
        </div>
      </div>

      {/* Branch Replication Status */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <h3 className="text-sm font-medium text-text-primary mb-3">
            Branch Replication
          </h3>
          <div className="space-y-3">
            {replicationStatus.map((branch, index) => (
              <div key={index} className="bg-muted/30 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-text-primary">
                    {branch.branch}
                  </span>
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={getStatusIcon(branch.status)} 
                      size={14} 
                      className={`${getStatusColor(branch.status)} ${
                        branch.status === 'syncing' ? 'animate-spin' : ''
                      }`}
                    />
                    <span className={`text-xs capitalize ${getStatusColor(branch.status)}`}>
                      {branch.status}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs text-text-secondary">
                  <span>{branch.sessionCount.toLocaleString()} sessions</span>
                  <span>Last sync: {formatTimestamp(branch.lastSync)}</span>
                </div>
                {branch.status === 'error' && (
                  <div className="mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleForceSync(branch.branch)}
                      iconName="RefreshCw"
                      iconSize={12}
                      className="text-xs"
                    >
                      Force Sync
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-subtle bg-muted/30">
        <div className="text-xs text-text-secondary text-center">
          System monitoring • Auto-refresh every 30s
        </div>
      </div>
    </div>
  );
};

export default SystemStatusPanel;